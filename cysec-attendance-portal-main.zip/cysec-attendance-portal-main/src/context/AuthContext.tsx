// src/context/AuthContext.tsx
// Authentication context managing session, role enforcement, 30m teacher inactivity timeout, and multi-tab sync

import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured, syncServerClock } from '../lib/supabase';
import { Profile, Student } from '../types/database';

interface AuthContextValue {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  student: Student | null;
  isLoading: boolean;
  isConfigured: boolean;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  setDemoUser: (role: 'teacher' | 'student') => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const TEACHER_INACTIVITY_LIMIT_MS = 30 * 60 * 1000; // 30 minutes

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [student, setStudent] = useState<Student | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const inactivityTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const signOut = useCallback(async () => {
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
    }
    if (isSupabaseConfigured) {
      try {
        await supabase.auth.signOut();
      } catch (_e) {
        // Ignore signout network error
      }
    }
    setUser(null);
    setSession(null);
    setProfile(null);
    setStudent(null);
  }, []);

  const fetchProfileAndStudent = useCallback(async (userId: string) => {
    try {
      // 1. Fetch profile
      const { data: profileData, error: profileErr } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (profileErr || !profileData) {
        // Profile missing or unauthorized -> sign out immediately (database is authority)
        await signOut();
        return;
      }

      setProfile(profileData as Profile);

      // 2. If student, fetch student record
      if (profileData.role === 'student') {
        const { data: studentData } = await supabase
          .from('students')
          .select('*')
          .eq('profile_id', userId)
          .eq('is_active', true)
          .single();

        if (studentData) {
          setStudent(studentData as Student);
        }
      }
    } catch (_e) {
      await signOut();
    }
  }, [signOut]);

  const refreshProfile = useCallback(async () => {
    if (user) {
      await fetchProfileAndStudent(user.id);
    }
  }, [user, fetchProfileAndStudent]);

  // Demo user helper for testing without live Supabase database
  const setDemoUser = useCallback((role: 'teacher' | 'student') => {
    if (role === 'teacher') {
      const demoTeacherId = '00000000-0000-0000-0000-000000000001';
      setUser({ id: demoTeacherId, email: 'teacher@school.edu' } as any);
      setProfile({
        id: demoTeacherId,
        role: 'teacher',
        full_name: 'Dr. Sarah Jenkins',
        must_change_password: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      setStudent(null);
    } else {
      const demoStudentId = '00000000-0000-0000-0000-000000000002';
      setUser({ id: demoStudentId, email: 'alice.chen@school.edu' } as any);
      setProfile({
        id: demoStudentId,
        role: 'student',
        full_name: 'Alice Chen',
        must_change_password: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      setStudent({
        id: '11111111-1111-1111-1111-111111111111',
        profile_id: demoStudentId,
        class_id: 'class-001',
        roll_number: 'CS-101-01',
        full_name: 'Alice Chen',
        email: 'alice.chen@school.edu',
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    }
    setIsLoading(false);
  }, []);

  // Monitor teacher activity for 30m timeout
  useEffect(() => {
    if (profile?.role !== 'teacher') return;

    const resetInactivityTimer = () => {
      if (inactivityTimerRef.current) {
        clearTimeout(inactivityTimerRef.current);
      }
      inactivityTimerRef.current = setTimeout(() => {
        signOut();
      }, TEACHER_INACTIVITY_LIMIT_MS);
    };

    resetInactivityTimer();

    const activityEvents = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart'];
    activityEvents.forEach((ev) => window.addEventListener(ev, resetInactivityTimer, { passive: true }));

    return () => {
      if (inactivityTimerRef.current) {
        clearTimeout(inactivityTimerRef.current);
      }
      activityEvents.forEach((ev) => window.removeEventListener(ev, resetInactivityTimer));
    };
  }, [profile?.role, signOut]);

  // Initial session check and auth state listener
  useEffect(() => {
    let mounted = true;

    if (!isSupabaseConfigured) {
      setIsLoading(false);
      return;
    }

    // Sync database clock offset
    syncServerClock();

    supabase.auth.getSession().then(({ data: { session: initialSession } }) => {
      if (!mounted) return;
      if (initialSession?.user) {
        setSession(initialSession);
        setUser(initialSession.user);
        fetchProfileAndStudent(initialSession.user.id).finally(() => {
          if (mounted) setIsLoading(false);
        });
      } else {
        setIsLoading(false);
      }
    });

    // Listen for auth events across all tabs (handles SIGNED_OUT across tabs)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      if (!mounted) return;

      if (event === 'SIGNED_OUT' || !newSession) {
        setUser(null);
        setSession(null);
        setProfile(null);
        setStudent(null);
        setIsLoading(false);
      } else if (newSession?.user) {
        setSession(newSession);
        setUser(newSession.user);
        await fetchProfileAndStudent(newSession.user.id);
        setIsLoading(false);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [fetchProfileAndStudent]);

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        profile,
        student,
        isLoading,
        isConfigured: isSupabaseConfigured,
        signOut,
        refreshProfile,
        setDemoUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
