// src/types/database.ts
// Strict TypeScript types mirroring Supabase PostgreSQL schema and RPCs

export type AppRole = 'teacher' | 'student';
export type SessionStatus = 'OPEN' | 'CLOSED' | 'CANCELLED';
export type AttendanceStatus = 'PRESENT' | 'LATE' | 'ABSENT';
export type AttendanceSource = 'SELF' | 'TEACHER' | 'SYSTEM';

export interface Profile {
  id: string;
  role: AppRole;
  full_name: string;
  must_change_password: boolean;
  created_at: string;
  updated_at: string;
}

export interface ClassItem {
  id: string;
  teacher_id: string;
  name: string;
  code: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Student {
  id: string;
  profile_id: string;
  class_id: string;
  roll_number: string;
  full_name: string;
  email: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Course {
  id: string;
  class_id: string;
  course_code: string;
  course_name: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface AttendanceSession {
  id: string;
  class_id: string;
  course_id: string;
  session_date: string;
  status: SessionStatus;
  opened_at: string;
  late_after: string;
  expires_at: string;
  closed_at: string | null;
  created_by: string;
  // Joined fields for display
  course?: {
    course_name: string;
    course_code: string;
  };
  class?: {
    name: string;
    code: string;
  };
}

export interface AttendanceRecord {
  id: string;
  session_id: string;
  student_id: string;
  status: AttendanceStatus;
  marked_at: string;
  marked_by: string | null;
  source: AttendanceSource;
  // Joined for display
  student?: {
    full_name: string;
    roll_number: string;
    email: string;
  };
}

export interface AuditLog {
  id: number;
  actor_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  metadata: Record<string, any>;
  created_at: string;
}

export interface StudentCourseStat {
  student_id: string;
  class_id: string;
  course_id: string;
  present_count: number;
  late_count: number;
  absent_count: number;
  total_sessions: number;
  attendance_pct: number;
  // Joined for display
  student_name?: string;
  roll_number?: string;
  course_name?: string;
  course_code?: string;
}

export type ConnectionState = 'LIVE' | 'RECONNECTING' | 'OFFLINE';
