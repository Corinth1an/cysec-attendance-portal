// src/pages/teacher/TeacherStudents.tsx
// Student management: class filtering, single add, batch CSV import, edit, deactivate, and password reset

import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Users,
  Upload,
  UserPlus,
  KeyRound,
  Edit2,
  Power,
  AlertCircle,
  FileSpreadsheet,
  CheckCircle2,
  X,
  Copy,
  Check,
} from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Student, ClassItem } from '../../types/database';
import { mapErrorMessage } from '../../lib/errorMapper';
import { parseStudentsCSV, ParsedStudentRow } from '../../lib/csv';
import { CredentialsDialog, CredentialResult } from '../../components/common/CredentialsDialog';
import { TableSkeleton } from '../../components/common/SkeletonLoader';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorState } from '../../components/common/ErrorState';

const singleStudentSchema = z.object({
  full_name: z.string().min(1, 'Full name is required').max(100, 'Max 100 characters').trim(),
  roll_number: z
    .string()
    .min(1, 'Roll number is required')
    .max(20, 'Max 20 characters')
    .regex(/^[A-Za-z0-9-]+$/, 'Alphanumeric and hyphens only')
    .trim(),
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Valid email required')
    .transform((v) => v.toLowerCase().trim()),
});

type SingleStudentFormValues = z.infer<typeof singleStudentSchema>;

export const TeacherStudents: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError } = useToast();

  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Single add modal
  const [singleAddModalOpen, setSingleAddModalOpen] = useState(false);
  const [isAddingSingle, setIsAddingSingle] = useState(false);

  // Edit modal
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  // CSV Import modal
  const [csvModalOpen, setCsvModalOpen] = useState(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [parsedRows, setParsedRows] = useState<ParsedStudentRow[]>([]);
  const [csvGlobalErrors, setCsvGlobalErrors] = useState<string[]>([]);
  const [isUploadingCSV, setIsUploadingCSV] = useState(false);

  // Credentials result dialog (show once)
  const [credentialsModalOpen, setCredentialsModalOpen] = useState(false);
  const [generatedCredentials, setGeneratedCredentials] = useState<CredentialResult[]>([]);

  // Password reset single modal
  const [resetResult, setResetResult] = useState<{
    studentName: string;
    tempPassword: string;
  } | null>(null);
  const [copiedReset, setCopiedReset] = useState(false);

  const {
    register: registerSingle,
    handleSubmit: handleSingleSubmit,
    reset: resetSingleForm,
    formState: { errors: singleErrors },
  } = useForm<SingleStudentFormValues>({
    resolver: zodResolver(singleStudentSchema),
  });

  const {
    register: registerEdit,
    handleSubmit: handleEditSubmit,
    reset: resetEditForm,
    setValue: setEditValue,
    formState: { errors: editErrors },
  } = useForm<{ full_name: string; roll_number: string }>({
    resolver: zodResolver(
      z.object({
        full_name: z.string().min(1).max(100).trim(),
        roll_number: z.string().regex(/^[A-Za-z0-9-]+$/),
      })
    ),
  });

  // Load teacher classes
  useEffect(() => {
    if (!user || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    const fetchClasses = async () => {
      try {
        const { data, error: clErr } = await supabase
          .from('classes')
          .select('*')
          .eq('teacher_id', user.id)
          .order('created_at', { ascending: false });

        if (clErr) throw clErr;
        const clsList = (data || []) as ClassItem[];
        setClasses(clsList);
        if (clsList.length > 0 && !selectedClassId) {
          setSelectedClassId(clsList[0].id);
        }
      } catch (err: any) {
        setError(mapErrorMessage(err));
      }
    };
    fetchClasses();
  }, [user]);

  // Load students for selected class
  const loadStudents = async () => {
    if (!selectedClassId || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { data, error: stErr } = await supabase
        .from('students')
        .select('*')
        .eq('class_id', selectedClassId)
        .order('roll_number', { ascending: true });

      if (stErr) throw stErr;
      setStudents((data || []) as Student[]);
    } catch (err: any) {
      setError(mapErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedClassId) {
      loadStudents();
    }
  }, [selectedClassId]);

  // 1. Single student add
  const onSingleSubmit = async (values: SingleStudentFormValues) => {
    if (!selectedClassId) return;
    setIsAddingSingle(true);

    try {
      // Call provision-students Edge Function
      const { data, error: fnError } = await supabase.functions.invoke('provision-students', {
        body: {
          class_id: selectedClassId,
          students: [values],
        },
      });

      if (fnError) {
        throw new Error(fnError.message || 'Provisioning function failed');
      }

      if (data?.results && data.results.length > 0) {
        const result = data.results[0];
        if (result.status === 'failed') {
          throw new Error(result.error || 'Failed to create student account');
        }
        setGeneratedCredentials(data.results);
        setCredentialsModalOpen(true);
        setSingleAddModalOpen(false);
        resetSingleForm();
        success(`Student ${values.full_name} created successfully.`);
        await loadStudents();
      }
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setIsAddingSingle(false);
    }
  };

  // 2. CSV File upload & parsing
  const handleCSVChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1024 * 1024) {
      setCsvGlobalErrors(['File size exceeds 1 MB limit.']);
      return;
    }

    setCsvFile(file);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const parseRes = parseStudentsCSV(text);
      setParsedRows(parseRes.rows);
      setCsvGlobalErrors(parseRes.globalErrors);
    };
    reader.readAsText(file);
  };

  const submitCSVImport = async () => {
    if (!selectedClassId || parsedRows.length === 0) return;
    const hasRowErrors = parsedRows.some((r) => r.errors.length > 0);
    if (hasRowErrors || csvGlobalErrors.length > 0) {
      toastError('Please fix all CSV validation errors before submitting.');
      return;
    }

    setIsUploadingCSV(true);
    try {
      const payload = {
        class_id: selectedClassId,
        students: parsedRows.map((r) => ({
          full_name: r.full_name,
          roll_number: r.roll_number,
          email: r.email,
        })),
      };

      const { data, error: fnError } = await supabase.functions.invoke('provision-students', {
        body: payload,
      });

      if (fnError) throw fnError;

      if (data?.results) {
        setGeneratedCredentials(data.results);
        setCredentialsModalOpen(true);
        setCsvModalOpen(false);
        setCsvFile(null);
        setParsedRows([]);
        success(`Processed ${data.results.length} student records.`);
        await loadStudents();
      }
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setIsUploadingCSV(false);
    }
  };

  // 3. Edit student
  const openEditModal = (student: Student) => {
    setEditingStudent(student);
    setEditValue('full_name', student.full_name);
    setEditValue('roll_number', student.roll_number);
  };

  const onEditSubmit = async (values: { full_name: string; roll_number: string }) => {
    if (!editingStudent) return;
    setIsEditing(true);
    try {
      const { error: updateErr } = await supabase
        .from('students')
        .update({
          full_name: values.full_name,
          roll_number: values.roll_number,
        })
        .eq('id', editingStudent.id);

      if (updateErr) throw updateErr;
      success('Student details updated.');
      setEditingStudent(null);
      await loadStudents();
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setIsEditing(false);
    }
  };

  // 4. Toggle active status
  const toggleStudentActive = async (student: Student) => {
    try {
      const { error: updateErr } = await supabase
        .from('students')
        .update({ is_active: !student.is_active })
        .eq('id', student.id);

      if (updateErr) throw updateErr;
      success(`Student marked as ${!student.is_active ? 'active' : 'inactive'}.`);
      await loadStudents();
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    }
  };

  // 5. Reset password
  const resetStudentPassword = async (student: Student) => {
    try {
      const { data, error: fnError } = await supabase.functions.invoke('reset-student-password', {
        body: { student_id: student.id },
      });

      if (fnError) throw fnError;

      if (data?.temp_password) {
        setResetResult({
          studentName: student.full_name,
          tempPassword: data.temp_password,
        });
        setCopiedReset(false);
      }
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Students Roster</h1>
          <p className="text-sm text-[#5B6675]">
            Provision and manage student accounts and enrollments.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setCsvModalOpen(true)}
            disabled={!selectedClassId}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-semibold rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] hover:bg-[#F7F8FA] transition-colors disabled:opacity-50"
          >
            <Upload className="w-4 h-4 text-[#5B6675]" />
            <span>CSV Import</span>
          </button>
          <button
            onClick={() => {
              resetSingleForm();
              setSingleAddModalOpen(true);
            }}
            disabled={!selectedClassId}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] transition-colors disabled:opacity-50"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Student</span>
          </button>
        </div>
      </div>

      {/* Class Selector Bar */}
      <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <label htmlFor="classSelect" className="text-xs font-semibold text-[#1B2430] uppercase tracking-wider shrink-0">
            Selected Class:
          </label>
          <select
            id="classSelect"
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="px-3 py-1.5 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] font-medium focus:ring-2 focus:ring-[#1F3A5F]"
          >
            {classes.map((cls) => (
              <option key={cls.id} value={cls.id}>
                {cls.name} ({cls.code}) {!cls.is_active ? '(Inactive)' : ''}
              </option>
            ))}
          </select>
        </div>
        <div className="text-xs text-[#5B6675]">
          Enrolled: <strong className="text-[#1B2430] font-semibold">{students.length}</strong> students
        </div>
      </div>

      {/* Students List */}
      {loading ? (
        <TableSkeleton rows={4} columns={5} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadStudents} />
      ) : students.length === 0 ? (
        <EmptyState
          title="No students in this class"
          description="Add students manually or import a batch roster via CSV."
          actionText="Add First Student"
          onAction={() => setSingleAddModalOpen(true)}
        />
      ) : (
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] text-xs font-semibold text-[#5B6675] uppercase tracking-wider">
                <tr>
                  <th className="p-3.5">Roll No</th>
                  <th className="p-3.5">Full Name</th>
                  <th className="p-3.5">Email</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {students.map((student) => (
                  <tr key={student.id} className="hover:bg-[#F7F8FA]">
                    <td className="p-3.5 font-mono font-medium text-[#1B2430] tabular-nums">
                      {student.roll_number}
                    </td>
                    <td className="p-3.5 font-semibold text-[#1B2430]">{student.full_name}</td>
                    <td className="p-3.5 text-xs text-[#5B6675]">{student.email}</td>
                    <td className="p-3.5">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${
                          student.is_active
                            ? 'bg-[#EAF5EF] text-[#1E7B4F] border border-[#C6E6D4]'
                            : 'bg-[#F1F3F5] text-[#5B6675] border border-[#E2E5EA]'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            student.is_active ? 'bg-[#1E7B4F]' : 'bg-[#5B6675]'
                          }`}
                        />
                        {student.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="p-3.5 text-right space-x-1.5">
                      <button
                        onClick={() => openEditModal(student)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA]"
                        title="Edit name and roll number"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-[#5B6675]" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => resetStudentPassword(student)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-[#E2E5EA] text-[#1F3A5F] hover:bg-[#EDF3FA]"
                        title="Reset temporary password"
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        <span>Reset PW</span>
                      </button>
                      <button
                        onClick={() => toggleStudentActive(student)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border ${
                          student.is_active
                            ? 'border-[#E2E5EA] text-[#5B6675] hover:text-[#B3261E] hover:bg-[#FDF0EF]'
                            : 'border-[#C6E6D4] text-[#1E7B4F] bg-[#EAF5EF]'
                        }`}
                        title={student.is_active ? 'Deactivate student' : 'Reactivate student'}
                      >
                        <Power className="w-3.5 h-3.5" />
                        <span>{student.is_active ? 'Deactivate' : 'Activate'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal: Add Single Student */}
      {singleAddModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-[1px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-lg p-6">
            <h2 className="text-lg font-bold text-[#1B2430] mb-4">Add Student Account</h2>
            <form onSubmit={handleSingleSubmit(onSingleSubmit)} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Alex Rivera"
                  className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                    singleErrors.full_name ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                  }`}
                  {...registerSingle('full_name')}
                />
                {singleErrors.full_name && (
                  <p className="mt-1 text-xs text-[#B3261E]">{singleErrors.full_name.message}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Roll Number
                </label>
                <input
                  type="text"
                  placeholder="e.g. CS-042"
                  className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                    singleErrors.roll_number ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                  }`}
                  {...registerSingle('roll_number')}
                />
                {singleErrors.roll_number && (
                  <p className="mt-1 text-xs text-[#B3261E]">{singleErrors.roll_number.message}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="student@school.edu"
                  className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                    singleErrors.email ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                  }`}
                  {...registerSingle('email')}
                />
                {singleErrors.email && (
                  <p className="mt-1 text-xs text-[#B3261E]">{singleErrors.email.message}</p>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-[#E2E5EA]">
                <button
                  type="button"
                  onClick={() => setSingleAddModalOpen(false)}
                  disabled={isAddingSingle}
                  className="px-4 py-2 text-sm font-medium rounded-[6px] border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isAddingSingle}
                  className="px-4 py-2 text-sm font-medium rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] disabled:opacity-50"
                >
                  {isAddingSingle ? 'Creating...' : 'Create Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Student */}
      {editingStudent && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-[1px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-lg p-6">
            <h2 className="text-lg font-bold text-[#1B2430] mb-4">Edit Student</h2>
            <form onSubmit={handleEditSubmit(onEditSubmit)} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F]"
                  {...registerEdit('full_name')}
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Roll Number
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F]"
                  {...registerEdit('roll_number')}
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#5B6675] uppercase tracking-wider mb-1">
                  Email (Immutable)
                </label>
                <input
                  type="email"
                  disabled
                  value={editingStudent.email}
                  className="w-full px-3 py-2 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#F7F8FA] text-[#5B6675] cursor-not-allowed"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-[#E2E5EA]">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  disabled={isEditing}
                  className="px-4 py-2 text-sm font-medium rounded-[6px] border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isEditing}
                  className="px-4 py-2 text-sm font-medium rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] disabled:opacity-50"
                >
                  {isEditing ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: CSV Import with Client Validation & Row-Error Preview */}
      {csvModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-[1px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-2xl bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-lg p-6 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-[#E2E5EA] mb-4">
              <h2 className="text-lg font-bold text-[#1B2430]">Batch CSV Import</h2>
              <button
                onClick={() => setCsvModalOpen(false)}
                className="text-[#5B6675] hover:text-[#1B2430] p-1 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-[#5B6675] mb-4 space-y-1">
              <p>
                Upload a CSV file containing columns: <code className="font-mono text-[#1F3A5F] font-semibold">full_name, roll_number, email</code>
              </p>
              <p>Limits: Maximum 100 students per batch, file size ≤ 1 MB.</p>
            </div>

            <div className="mb-4">
              <input
                type="file"
                accept=".csv,text/csv"
                onChange={handleCSVChange}
                className="block w-full text-xs text-[#5B6675] file:mr-3 file:py-2 file:px-3 file:rounded-[4px] file:border-0 file:text-xs file:font-semibold file:bg-[#EDF3FA] file:text-[#1F3A5F] hover:file:bg-[#D0DFEF] cursor-pointer"
              />
            </div>

            {csvGlobalErrors.length > 0 && (
              <div className="mb-4 p-3 rounded-[4px] bg-[#FDF0EF] border border-[#F8CBC8] text-xs text-[#B3261E] space-y-1">
                {csvGlobalErrors.map((err, i) => (
                  <p key={i}>• {err}</p>
                ))}
              </div>
            )}

            {parsedRows.length > 0 && (
              <div className="flex-1 overflow-auto border border-[#E2E5EA] rounded-[4px] mb-4">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] sticky top-0">
                    <tr>
                      <th className="p-2 font-semibold text-[#1B2430]">Row</th>
                      <th className="p-2 font-semibold text-[#1B2430]">Full Name</th>
                      <th className="p-2 font-semibold text-[#1B2430]">Roll No</th>
                      <th className="p-2 font-semibold text-[#1B2430]">Email</th>
                      <th className="p-2 font-semibold text-[#1B2430]">Validation</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2E5EA]">
                    {parsedRows.map((row) => (
                      <tr
                        key={row.rowNumber}
                        className={row.errors.length > 0 ? 'bg-[#FDF0EF]' : 'hover:bg-[#F7F8FA]'}
                      >
                        <td className="p-2 text-[#5B6675] tabular-nums font-mono">{row.rowNumber}</td>
                        <td className="p-2 font-medium text-[#1B2430]">{row.full_name || '—'}</td>
                        <td className="p-2 font-mono text-[#1B2430]">{row.roll_number || '—'}</td>
                        <td className="p-2 text-[#5B6675]">{row.email || '—'}</td>
                        <td className="p-2">
                          {row.errors.length > 0 ? (
                            <span className="text-[#B3261E] font-medium">{row.errors.join('; ')}</span>
                          ) : (
                            <span className="text-[#1E7B4F] inline-flex items-center gap-1 font-medium">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Valid
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-3 border-t border-[#E2E5EA]">
              <button
                type="button"
                onClick={() => setCsvModalOpen(false)}
                disabled={isUploadingCSV}
                className="px-4 py-2 text-sm font-medium rounded-[6px] border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={submitCSVImport}
                disabled={
                  isUploadingCSV ||
                  parsedRows.length === 0 ||
                  parsedRows.some((r) => r.errors.length > 0) ||
                  csvGlobalErrors.length > 0
                }
                className="px-4 py-2 text-sm font-semibold rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] disabled:opacity-40"
              >
                {isUploadingCSV ? 'Importing Roster...' : `Import ${parsedRows.length} Students`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Password Result Dialog */}
      {resetResult && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-[1px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-lg p-6 animate-in fade-in zoom-in-95 duration-100">
            <h3 className="text-lg font-bold text-[#1B2430] mb-2">Password Reset Successful</h3>
            <p className="text-xs text-[#5B6675] mb-4">
              A new temporary password was generated for <strong>{resetResult.studentName}</strong>. The student must change this password on their next login.
            </p>

            <div className="p-3 bg-[#EDF3FA] border border-[#D0DFEF] rounded-[6px] flex items-center justify-between gap-2 mb-6">
              <span className="font-mono text-sm font-semibold text-[#1F3A5F] select-all">
                {resetResult.tempPassword}
              </span>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(resetResult.tempPassword);
                  setCopiedReset(true);
                  setTimeout(() => setCopiedReset(false), 2000);
                }}
                className="p-1.5 rounded hover:bg-[#D0DFEF] text-[#1F3A5F] transition-colors"
                title="Copy password"
              >
                {copiedReset ? <Check className="w-4 h-4 text-[#1E7B4F]" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setResetResult(null)}
                className="px-4 py-2 text-sm font-semibold rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45]"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Batch Credentials Dialog (Show once with CSV download) */}
      <CredentialsDialog
        isOpen={credentialsModalOpen}
        credentials={generatedCredentials}
        onClose={() => setCredentialsModalOpen(false)}
      />
    </div>
  );
};
