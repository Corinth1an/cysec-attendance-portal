// src/pages/teacher/TeacherDashboard.tsx
import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Radio, Users, Layers, BookOpen, Clock, ArrowRight, AlertCircle, PlusCircle } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { ClassItem, AttendanceSession, AttendanceRecord, StudentCourseStat } from '../../types/database';
import { StatCard } from '../../components/common/StatCard';
import { StatusChip } from '../../components/common/StatusChip';
import { CardSkeleton } from '../../components/common/SkeletonLoader';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorState } from '../../components/common/ErrorState';

export const TeacherDashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [openSession, setOpenSession] = useState<AttendanceSession | null>(null);
  const [sessionRecords, setSessionRecords] = useState<AttendanceRecord[]>([]);
  const [totalStudents, setTotalStudents] = useState<number>(0);
  const [recentSessions, setRecentSessions] = useState<AttendanceSession[]>([]);

  const loadDashboardData = useCallback(async () => {
    if (!user || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);

    try {
      // 1. Fetch teacher's classes
      const { data: classesData, error: classesErr } = await supabase
        .from('classes')
        .select('*')
        .eq('teacher_id', user.id)
        .order('created_at', { ascending: false });

      if (classesErr) throw classesErr;
      const myClasses = (classesData || []) as ClassItem[];
      setClasses(myClasses);

      if (myClasses.length === 0) {
        setLoading(false);
        return;
      }

      const classIds = myClasses.map((c) => c.id);

      // 2. Fetch total active students across classes
      const { count: studentCount } = await supabase
        .from('students')
        .select('id', { count: 'exact', head: true })
        .in('class_id', classIds)
        .eq('is_active', true);

      setTotalStudents(studentCount || 0);

      // 3. Check for OPEN session
      const { data: openSessionData } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .in('class_id', classIds)
        .eq('status', 'OPEN')
        .order('opened_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (openSessionData) {
        const formattedSession: AttendanceSession = {
          ...openSessionData,
          course: openSessionData.courses,
          class: openSessionData.classes,
        };
        setOpenSession(formattedSession);

        // Fetch attendance records for this open session
        const { data: recordsData } = await supabase
          .from('attendance')
          .select('*, students(full_name, roll_number, email)')
          .eq('session_id', openSessionData.id);

        setSessionRecords(
          (recordsData || []).map((r: any) => ({
            ...r,
            student: r.students,
          }))
        );
      } else {
        setOpenSession(null);
        setSessionRecords([]);
      }

      // 4. Fetch recent sessions
      const { data: recentData } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .in('class_id', classIds)
        .neq('status', 'OPEN')
        .order('opened_at', { ascending: false })
        .limit(4);

      if (recentData) {
        setRecentSessions(
          recentData.map((s: any) => ({
            ...s,
            course: s.courses,
            class: s.classes,
          }))
        );
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to load dashboard data.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
        </div>
        <CardSkeleton />
      </div>
    );
  }

  if (error) {
    return <ErrorState message={error} onRetry={loadDashboardData} />;
  }

  const presentCount = sessionRecords.filter((r) => r.status === 'PRESENT').length;
  const lateCount = sessionRecords.filter((r) => r.status === 'LATE').length;
  const markedTotal = presentCount + lateCount;

  return (
    <div className="space-y-6">
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Faculty Overview</h1>
          <p className="text-sm text-[#5B6675]">Manage your classes, live sessions, and attendance rosters.</p>
        </div>
        <button
          onClick={() => navigate('/t/live')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-[6px] bg-[#1F3A5F] text-white text-sm font-semibold hover:bg-[#162a45] transition-colors shadow-sm self-start sm:self-auto"
        >
          <Radio className="w-4 h-4 text-white" />
          <span>{openSession ? 'Go to Live Session' : 'Open Attendance Session'}</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          label="Active Classes"
          value={`${classes.length} / 2`}
          subtext={classes.length >= 2 ? 'Maximum capacity reached' : '1 class slot available'}
          icon={<Layers className="w-5 h-5" />}
        />
        <StatCard
          label="Enrolled Students"
          value={totalStudents}
          subtext="Active across all classes"
          icon={<Users className="w-5 h-5" />}
        />
        <StatCard
          label="Live Status"
          value={openSession ? 'Active Session' : 'Idle'}
          subtext={openSession ? `${openSession.course?.course_code} in progress` : 'No active session'}
          icon={<Radio className="w-5 h-5" />}
          highlight={openSession ? 'success' : 'normal'}
        />
      </div>

      {/* Live Session Active Alert Card */}
      {openSession ? (
        <div className="bg-[#FFFFFF] border-2 border-[#1F3A5F] rounded-[6px] p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E2E5EA]">
            <div className="flex items-center gap-3">
              <StatusChip status="OPEN" />
              <div>
                <h2 className="text-lg font-bold text-[#1B2430]">
                  {openSession.course?.course_name} ({openSession.course?.course_code})
                </h2>
                <p className="text-xs text-[#5B6675]">
                  Class: {openSession.class?.name} • Opened at {new Date(openSession.opened_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
            <button
              onClick={() => navigate('/t/live')}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-[4px] bg-[#1F3A5F] text-white text-xs font-semibold hover:bg-[#162a45] transition-colors self-start sm:self-auto"
            >
              <span>Manage Session</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-4 pt-4 text-center">
            <div className="p-3 bg-[#EAF5EF] rounded-[4px]">
              <span className="text-xs font-medium text-[#1E7B4F] uppercase tracking-wider block">Present</span>
              <span className="text-2xl font-bold tabular-nums text-[#1E7B4F]">{presentCount}</span>
            </div>
            <div className="p-3 bg-[#FDF6EC] rounded-[4px]">
              <span className="text-xs font-medium text-[#A15C00] uppercase tracking-wider block">Late</span>
              <span className="text-2xl font-bold tabular-nums text-[#A15C00]">{lateCount}</span>
            </div>
            <div className="p-3 bg-[#F1F3F5] rounded-[4px]">
              <span className="text-xs font-medium text-[#5B6675] uppercase tracking-wider block">Total Marked</span>
              <span className="text-2xl font-bold tabular-nums text-[#1B2430]">{markedTotal}</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-[6px] bg-[#EDF3FA] text-[#1F3A5F] flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-[#1B2430]">No Attendance Session Currently Active</h3>
              <p className="text-xs text-[#5B6675]">Open a new session to allow enrolled students to mark attendance.</p>
            </div>
          </div>
          <button
            onClick={() => navigate('/t/live')}
            className="px-4 py-2 text-sm font-semibold rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] transition-colors shrink-0"
          >
            Launch Session
          </button>
        </div>
      )}

      {/* Classes Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold text-[#1B2430]">Your Classes ({classes.length}/2)</h2>
          {classes.length < 2 && (
            <button
              onClick={() => navigate('/t/classes')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1F3A5F] hover:underline"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Create Class</span>
            </button>
          )}
        </div>

        {classes.length === 0 ? (
          <EmptyState
            title="No classes created yet"
            description="You need to create your first class before provisioning students or opening attendance sessions."
            actionText="Create Class"
            onAction={() => navigate('/t/classes')}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {classes.map((cls) => (
              <div
                key={cls.id}
                className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-5 flex flex-col justify-between hover:border-[#1F3A5F] transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-[#F1F3F5] text-[#5B6675] border border-[#E2E5EA]">
                      {cls.code}
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded font-medium ${
                        cls.is_active ? 'text-[#1E7B4F] bg-[#EAF5EF]' : 'text-[#5B6675] bg-[#F1F3F5]'
                      }`}
                    >
                      {cls.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold text-[#1B2430] mb-1">{cls.name}</h3>
                </div>

                <div className="flex items-center justify-between pt-4 mt-4 border-t border-[#E2E5EA]">
                  <button
                    onClick={() => navigate('/t/students')}
                    className="text-xs font-semibold text-[#1F3A5F] hover:underline"
                  >
                    View Students
                  </button>
                  <button
                    onClick={() => navigate('/t/courses')}
                    className="text-xs font-semibold text-[#5B6675] hover:text-[#1B2430]"
                  >
                    Manage Courses
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent Finalized Sessions */}
      {recentSessions.length > 0 && (
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-semibold text-[#1B2430]">Recent Closed Sessions</h2>
            <button
              onClick={() => navigate('/t/history')}
              className="text-xs font-semibold text-[#1F3A5F] hover:underline"
            >
              View Full History
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA]">
                <tr>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Date</th>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Course</th>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Class</th>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Status</th>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Opened</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {recentSessions.map((session) => (
                  <tr key={session.id} className="hover:bg-[#F7F8FA]">
                    <td className="p-2.5 text-[#1B2430] font-medium">{session.session_date}</td>
                    <td className="p-2.5 text-[#1B2430]">{session.course?.course_name} ({session.course?.course_code})</td>
                    <td className="p-2.5 text-[#5B6675]">{session.class?.name}</td>
                    <td className="p-2.5">
                      <StatusChip status={session.status} />
                    </td>
                    <td className="p-2.5 tabular-nums text-[#5B6675]">
                      {new Date(session.opened_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
