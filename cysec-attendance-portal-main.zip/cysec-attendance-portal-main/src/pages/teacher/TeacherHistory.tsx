// src/pages/teacher/TeacherHistory.tsx
// History viewer with multi-criteria filtering and session detail view with manual correction

import React, { useEffect, useState } from 'react';
import {
  History,
  Filter,
  Eye,
  Calendar,
  Layers,
  BookOpen,
  X,
  Lock,
} from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import {
  ClassItem,
  Course,
  AttendanceSession,
  AttendanceRecord,
  AttendanceStatus,
} from '../../types/database';
import { mapErrorMessage } from '../../lib/errorMapper';
import { StatusChip } from '../../components/common/StatusChip';
import { TableSkeleton } from '../../components/common/SkeletonLoader';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorState } from '../../components/common/ErrorState';

export const TeacherHistory: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError } = useToast();

  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [sessions, setSessions] = useState<AttendanceSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [filterClassId, setFilterClassId] = useState<string>('all');
  const [filterCourseId, setFilterCourseId] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterDateFrom, setFilterDateFrom] = useState<string>('');
  const [filterDateTo, setFilterDateTo] = useState<string>('');

  // Selected session detail modal
  const [selectedSession, setSelectedSession] = useState<AttendanceSession | null>(null);
  const [sessionDetailRecords, setSessionDetailRecords] = useState<AttendanceRecord[]>([]);
  const [detailLoading, setDetailLoading] = useState(false);

  useEffect(() => {
    if (!user || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    const loadMeta = async () => {
      try {
        const { data: clsData } = await supabase
          .from('classes')
          .select('*')
          .eq('teacher_id', user.id);
        const clsList = (clsData || []) as ClassItem[];
        setClasses(clsList);

        if (clsList.length > 0) {
          const { data: coData } = await supabase
            .from('courses')
            .select('*')
            .in('class_id', clsList.map((c) => c.id));
          setCourses((coData || []) as Course[]);
        }
      } catch (err: any) {
        setError(mapErrorMessage(err));
      }
    };

    loadMeta();
  }, [user]);

  const loadSessions = async () => {
    if (!user || !isSupabaseConfigured) return;
    setLoading(true);
    setError(null);

    try {
      let query = supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .order('opened_at', { ascending: false });

      if (filterClassId !== 'all') {
        query = query.eq('class_id', filterClassId);
      }
      if (filterCourseId !== 'all') {
        query = query.eq('course_id', filterCourseId);
      }
      if (filterStatus !== 'all') {
        query = query.eq('status', filterStatus);
      }
      if (filterDateFrom) {
        query = query.gte('session_date', filterDateFrom);
      }
      if (filterDateTo) {
        query = query.lte('session_date', filterDateTo);
      }

      const { data, error: qErr } = await query;
      if (qErr) throw qErr;

      setSessions(
        (data || []).map((s: any) => ({
          ...s,
          course: s.courses,
          class: s.classes,
        }))
      );
    } catch (err: any) {
      setError(mapErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSessions();
  }, [filterClassId, filterCourseId, filterStatus, filterDateFrom, filterDateTo]);

  // Load session detail
  const viewSessionDetail = async (sess: AttendanceSession) => {
    setSelectedSession(sess);
    setDetailLoading(true);
    try {
      const { data, error: recErr } = await supabase
        .from('attendance')
        .select('*, students(full_name, roll_number, email)')
        .eq('session_id', sess.id)
        .order('marked_at', { ascending: true });

      if (recErr) throw recErr;

      setSessionDetailRecords(
        (data || []).map((r: any) => ({
          ...r,
          student: r.students,
        }))
      );
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setDetailLoading(false);
    }
  };

  // Manual correction on past session
  const handleCorrection = async (studentId: string, newStatus: AttendanceStatus) => {
    if (!selectedSession) return;
    try {
      const { data, error: rpcErr } = await supabase.rpc('set_attendance', {
        p_session_id: selectedSession.id,
        p_student_id: studentId,
        p_status: newStatus,
      });

      if (rpcErr) throw rpcErr;

      setSessionDetailRecords((prev) =>
        prev.map((r) =>
          r.student_id === studentId
            ? { ...r, status: newStatus, marked_at: data.marked_at, source: 'TEACHER' }
            : r
        )
      );

      success('Attendance record updated.');
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Session History</h1>
        <p className="text-sm text-[#5B6675]">Review past sessions and make official corrections.</p>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-4 space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase text-[#5B6675]">
          <Filter className="w-3.5 h-3.5" />
          <span>Filters</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
          {/* Class Filter */}
          <div>
            <label className="block text-xs font-medium text-[#5B6675] mb-1">Class</label>
            <select
              value={filterClassId}
              onChange={(e) => setFilterClassId(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-[4px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430]"
            >
              <option value="all">All Classes</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Course Filter */}
          <div>
            <label className="block text-xs font-medium text-[#5B6675] mb-1">Course</label>
            <select
              value={filterCourseId}
              onChange={(e) => setFilterCourseId(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-[4px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430]"
            >
              <option value="all">All Courses</option>
              {courses.map((co) => (
                <option key={co.id} value={co.id}>
                  {co.course_code} - {co.course_name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-xs font-medium text-[#5B6675] mb-1">Status</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-[4px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430]"
            >
              <option value="all">All Statuses</option>
              <option value="OPEN">Open</option>
              <option value="CLOSED">Closed</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
          </div>

          {/* Date From */}
          <div>
            <label className="block text-xs font-medium text-[#5B6675] mb-1">From Date</label>
            <input
              type="date"
              value={filterDateFrom}
              onChange={(e) => setFilterDateFrom(e.target.value)}
              className="w-full px-2 py-1 text-xs rounded-[4px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430]"
            />
          </div>

          {/* Date To */}
          <div>
            <label className="block text-xs font-medium text-[#5B6675] mb-1">To Date</label>
            <input
              type="date"
              value={filterDateTo}
              onChange={(e) => setFilterDateTo(e.target.value)}
              className="w-full px-2 py-1 text-xs rounded-[4px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430]"
            />
          </div>
        </div>
      </div>

      {/* Sessions Table */}
      {loading ? (
        <TableSkeleton rows={5} columns={6} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadSessions} />
      ) : sessions.length === 0 ? (
        <EmptyState
          title="No sessions found"
          description="No attendance sessions matched your filter criteria."
        />
      ) : (
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] text-xs font-semibold text-[#5B6675] uppercase tracking-wider">
                <tr>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Course</th>
                  <th className="p-3.5">Class</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Opened</th>
                  <th className="p-3.5">Closed</th>
                  <th className="p-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {sessions.map((sess) => (
                  <tr key={sess.id} className="hover:bg-[#F7F8FA]">
                    <td className="p-3.5 font-medium text-[#1B2430] tabular-nums">
                      {sess.session_date}
                    </td>
                    <td className="p-3.5 font-semibold text-[#1B2430]">
                      {sess.course?.course_name} ({sess.course?.course_code})
                    </td>
                    <td className="p-3.5 text-xs text-[#5B6675]">{sess.class?.name}</td>
                    <td className="p-3.5">
                      <StatusChip status={sess.status} />
                    </td>
                    <td className="p-3.5 text-xs text-[#5B6675] tabular-nums">
                      {new Date(sess.opened_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="p-3.5 text-xs text-[#5B6675] tabular-nums">
                      {sess.closed_at
                        ? new Date(sess.closed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                        : '—'}
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => viewSessionDetail(sess)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-[#E2E5EA] text-[#1F3A5F] hover:bg-[#EDF3FA] transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Roster</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Session Detail Modal */}
      {selectedSession && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-[1px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-3xl bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-lg p-6 max-h-[85vh] flex flex-col">
            <div className="flex items-start justify-between pb-3 border-b border-[#E2E5EA] mb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <StatusChip status={selectedSession.status} />
                  <span className="text-xs text-[#5B6675]">Date: {selectedSession.session_date}</span>
                </div>
                <h3 className="text-lg font-bold text-[#1B2430]">
                  {selectedSession.course?.course_name} ({selectedSession.course?.course_code})
                </h3>
                <p className="text-xs text-[#5B6675]">Class: {selectedSession.class?.name}</p>
              </div>
              <button
                onClick={() => setSelectedSession(null)}
                className="text-[#5B6675] hover:text-[#1B2430] p-1 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {detailLoading ? (
              <TableSkeleton rows={4} columns={4} />
            ) : (
              <div className="flex-1 overflow-auto border border-[#E2E5EA] rounded-[4px] mb-4">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] sticky top-0">
                    <tr>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Roll No</th>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Full Name</th>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Status</th>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Marked At</th>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Source</th>
                      {selectedSession.status !== 'CANCELLED' && (
                        <th className="p-2.5 text-right font-semibold text-[#1B2430]">Correction</th>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2E5EA]">
                    {sessionDetailRecords.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-4 text-center text-[#5B6675]">
                          No attendance records found for this session.
                        </td>
                      </tr>
                    ) : (
                      sessionDetailRecords.map((rec) => (
                        <tr key={rec.id} className="hover:bg-[#F7F8FA]">
                          <td className="p-2.5 font-mono font-medium text-[#1B2430] tabular-nums">
                            {rec.student?.roll_number}
                          </td>
                          <td className="p-2.5 font-semibold text-[#1B2430]">
                            {rec.student?.full_name}
                          </td>
                          <td className="p-2.5">
                            <StatusChip status={rec.status} />
                          </td>
                          <td className="p-2.5 text-[#5B6675] tabular-nums">
                            {new Date(rec.marked_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </td>
                          <td className="p-2.5 text-[#5B6675]">{rec.source}</td>
                          {selectedSession.status !== 'CANCELLED' && (
                            <td className="p-2.5 text-right">
                              <select
                                value={rec.status}
                                onChange={(e) =>
                                  handleCorrection(rec.student_id, e.target.value as AttendanceStatus)
                                }
                                className="text-xs px-2 py-1 rounded border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430]"
                              >
                                <option value="PRESENT">Present</option>
                                <option value="LATE">Late</option>
                                <option value="ABSENT">Absent</option>
                              </select>
                            </td>
                          )}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            <div className="flex justify-end pt-3 border-t border-[#E2E5EA]">
              <button
                type="button"
                onClick={() => setSelectedSession(null)}
                className="px-4 py-2 text-sm font-medium rounded-[6px] border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
