// src/pages/teacher/TeacherClasses.tsx
// Management of teacher's classes (strictly maximum 2 classes, enforced in UI and database trigger)

import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Layers, Plus, Edit2, Check, AlertCircle, ShieldAlert, Power } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { ClassItem } from '../../types/database';
import { mapErrorMessage } from '../../lib/errorMapper';
import { TableSkeleton } from '../../components/common/SkeletonLoader';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorState } from '../../components/common/ErrorState';

const classSchema = z.object({
  name: z
    .string()
    .min(1, 'Class name is required')
    .max(80, 'Class name cannot exceed 80 characters')
    .trim(),
  code: z
    .string()
    .min(1, 'Class code is required')
    .max(20, 'Class code cannot exceed 20 characters')
    .regex(/^[A-Za-z0-9-]+$/, 'Code must be alphanumeric (hyphens allowed)')
    .trim(),
  is_active: z.boolean(),
});

type ClassFormValues = {
  name: string;
  code: string;
  is_active: boolean;
};

export const TeacherClasses: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError } = useToast();

  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<ClassItem | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm<ClassFormValues>({
    resolver: zodResolver(classSchema),
    defaultValues: { is_active: true },
  });

  const loadClasses = async () => {
    if (!user || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { data, error: fetchErr } = await supabase
        .from('classes')
        .select('*')
        .eq('teacher_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchErr) throw fetchErr;
      setClasses((data || []) as ClassItem[]);
    } catch (err: any) {
      setError(mapErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadClasses();
  }, [user]);

  const openCreateModal = () => {
    if (classes.length >= 2) {
      toastError('You have reached the maximum limit of 2 classes.');
      return;
    }
    setEditingClass(null);
    reset({ name: '', code: '', is_active: true });
    setModalOpen(true);
  };

  const openEditModal = (item: ClassItem) => {
    setEditingClass(item);
    setValue('name', item.name);
    setValue('code', item.code);
    setValue('is_active', item.is_active);
    setModalOpen(true);
  };

  const onSubmit = async (values: ClassFormValues) => {
    if (!user) return;
    setIsSubmitting(true);

    try {
      if (editingClass) {
        // Update existing class (only name, code, is_active per grant)
        const { error: updateErr } = await supabase
          .from('classes')
          .update({
            name: values.name,
            code: values.code,
            is_active: values.is_active,
          })
          .eq('id', editingClass.id);

        if (updateErr) throw updateErr;
        success('Class updated successfully.');
      } else {
        // Create new class
        if (classes.length >= 2) {
          throw new Error('CLASS_LIMIT');
        }
        const { error: insertErr } = await supabase.from('classes').insert({
          teacher_id: user.id,
          name: values.name,
          code: values.code,
          is_active: values.is_active,
        });

        if (insertErr) throw insertErr;
        success('Class created successfully.');
      }

      setModalOpen(false);
      await loadClasses();
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleClassActive = async (cls: ClassItem) => {
    try {
      const { error: updateErr } = await supabase
        .from('classes')
        .update({ is_active: !cls.is_active })
        .eq('id', cls.id);

      if (updateErr) throw updateErr;
      success(`Class "${cls.name}" is now ${!cls.is_active ? 'active' : 'inactive'}.`);
      await loadClasses();
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Classes</h1>
          <p className="text-sm text-[#5B6675]">
            Configure and manage your teaching classes (maximum 2 classes allowed).
          </p>
        </div>
        <button
          onClick={openCreateModal}
          disabled={classes.length >= 2}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] transition-colors disabled:opacity-40 disabled:cursor-not-allowed self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Class ({classes.length}/2)</span>
        </button>
      </div>

      {classes.length >= 2 && (
        <div className="p-3.5 rounded-[6px] bg-[#EDF3FA] border border-[#D0DFEF] text-xs text-[#1F3A5F] flex items-center gap-2.5">
          <ShieldAlert className="w-4 h-4 shrink-0 text-[#1F3A5F]" />
          <span>
            Class capacity reached (2 of 2 classes used). To create a new class, deactivate or repurpose an existing class.
          </span>
        </div>
      )}

      {loading ? (
        <TableSkeleton rows={2} columns={4} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadClasses} />
      ) : classes.length === 0 ? (
        <EmptyState
          title="No classes created"
          description="Create your first class to begin managing students and taking attendance."
          actionText="Create Class"
          onAction={openCreateModal}
        />
      ) : (
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] text-xs font-semibold text-[#5B6675] uppercase tracking-wider">
                <tr>
                  <th className="p-3.5">Code</th>
                  <th className="p-3.5">Class Name</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Created</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {classes.map((cls) => (
                  <tr key={cls.id} className="hover:bg-[#F7F8FA]">
                    <td className="p-3.5 font-mono font-medium text-[#1F3A5F]">{cls.code}</td>
                    <td className="p-3.5 font-semibold text-[#1B2430]">{cls.name}</td>
                    <td className="p-3.5">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${
                          cls.is_active
                            ? 'bg-[#EAF5EF] text-[#1E7B4F] border border-[#C6E6D4]'
                            : 'bg-[#F1F3F5] text-[#5B6675] border border-[#E2E5EA]'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            cls.is_active ? 'bg-[#1E7B4F]' : 'bg-[#5B6675]'
                          }`}
                        />
                        {cls.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="p-3.5 text-xs text-[#5B6675]">
                      {new Date(cls.created_at).toLocaleDateString()}
                    </td>
                    <td className="p-3.5 text-right space-x-2">
                      <button
                        onClick={() => openEditModal(cls)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA] transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-[#5B6675]" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => toggleClassActive(cls)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border transition-colors ${
                          cls.is_active
                            ? 'border-[#E2E5EA] text-[#5B6675] hover:text-[#B3261E] hover:bg-[#FDF0EF]'
                            : 'border-[#C6E6D4] text-[#1E7B4F] bg-[#EAF5EF] hover:bg-[#D9EFE3]'
                        }`}
                      >
                        <Power className="w-3.5 h-3.5" />
                        <span>{cls.is_active ? 'Deactivate' : 'Activate'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Class Create / Edit Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-[1px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-lg p-6">
            <h2 className="text-lg font-bold text-[#1B2430] mb-4">
              {editingClass ? 'Edit Class Details' : 'Create New Class'}
            </h2>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Class Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Computer Science A"
                  className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                    errors.name ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                  }`}
                  {...register('name')}
                />
                {errors.name && <p className="mt-1 text-xs text-[#B3261E]">{errors.name.message}</p>}
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Class Code
                </label>
                <input
                  type="text"
                  placeholder="e.g. CS-101"
                  className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                    errors.code ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                  }`}
                  {...register('code')}
                />
                {errors.code && <p className="mt-1 text-xs text-[#B3261E]">{errors.code.message}</p>}
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  id="is_active"
                  type="checkbox"
                  className="rounded border-[#E2E5EA] text-[#1F3A5F] focus:ring-[#1F3A5F]"
                  {...register('is_active')}
                />
                <label htmlFor="is_active" className="text-sm font-medium text-[#1B2430]">
                  Active for new sessions and student enrollment
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-[#E2E5EA]">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium rounded-[6px] border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : editingClass ? 'Save Changes' : 'Create Class'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
