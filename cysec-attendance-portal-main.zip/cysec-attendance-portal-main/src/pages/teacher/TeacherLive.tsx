// src/pages/teacher/TeacherLive.tsx
// Realtime attendance control: live countdown with server clock skew, idempotent realtime roster, manual corrections, close & cancel actions

import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Radio,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Lock,
  RefreshCw,
  Sliders,
  ChevronDown,
} from 'lucide-react';
import { supabase, isSupabaseConfigured, getServerTime, syncServerClock } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import {
  ClassItem,
  Course,
  Student,
  AttendanceSession,
  AttendanceRecord,
  AttendanceStatus,
} from '../../types/database';
import { mapErrorMessage } from '../../lib/errorMapper';
import { formatTimeRemaining } from '../../lib/utils';
import { StatusChip } from '../../components/common/StatusChip';
import { ConfirmDialog } from '../../components/common/ConfirmDialog';
import { CardSkeleton, TableSkeleton } from '../../components/common/SkeletonLoader';
import { ErrorState } from '../../components/common/ErrorState';

export const TeacherLive: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError, info } = useToast();
  const [searchParams] = useSearchParams();

  // Setup / Classes / Courses
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [selectedCourseId, setSelectedCourseId] = useState<string>('');
  const [durationMinutes, setDurationMinutes] = useState<number>(10);
  const [lateMinutes, setLateMinutes] = useState<number>(5);

  // Active or Selected Session State
  const [session, setSession] = useState<AttendanceSession | null>(null);
  const [classStudents, setClassStudents] = useState<Student[]>([]);
  const [attendanceMap, setAttendanceMap] = useState<Map<string, AttendanceRecord>>(new Map());

  // Loading & Action states
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Time Remaining calculation
  const [timeRemainingMs, setTimeRemainingMs] = useState<number>(0);
  const [isExpired, setIsExpired] = useState<boolean>(false);

  // Modals
  const [closeConfirmOpen, setCloseConfirmOpen] = useState(false);
  const [cancelConfirmOpen, setCancelConfirmOpen] = useState(false);

  // Fetch initial classes and check for open sessions
  const loadInitialData = useCallback(async () => {
    if (!user || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);

    try {
      await syncServerClock();

      // 1. Fetch teacher classes
      const { data: clsData, error: clsErr } = await supabase
        .from('classes')
        .select('*')
        .eq('teacher_id', user.id)
        .order('created_at', { ascending: false });

      if (clsErr) throw clsErr;
      const myClasses = (clsData || []) as ClassItem[];
      setClasses(myClasses);

      if (myClasses.length === 0) {
        setLoading(false);
        return;
      }

      const activeClassIds = myClasses.map((c) => c.id);

      // Check if any session is currently OPEN
      const { data: openSessionData, error: sessionErr } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .in('class_id', activeClassIds)
        .eq('status', 'OPEN')
        .order('opened_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (sessionErr) throw sessionErr;

      if (openSessionData) {
        const fullSession: AttendanceSession = {
          ...openSessionData,
          course: openSessionData.courses,
          class: openSessionData.classes,
        };
        setSession(fullSession);
        setSelectedClassId(fullSession.class_id);
        setSelectedCourseId(fullSession.course_id);
        await loadSessionRoster(fullSession);
      } else {
        const defaultClassId = searchParams.get('classId') || myClasses[0].id;
        setSelectedClassId(defaultClassId);
      }
    } catch (err: any) {
      setError(mapErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [user, searchParams]);

  // Load courses when selected class changes
  useEffect(() => {
    if (!selectedClassId || !isSupabaseConfigured) return;
    const fetchCourses = async () => {
      const { data } = await supabase
        .from('courses')
        .select('*')
        .eq('class_id', selectedClassId)
        .eq('is_active', true)
        .order('course_code', { ascending: true });

      const courseList = (data || []) as Course[];
      setCourses(courseList);
      if (courseList.length > 0 && !selectedCourseId) {
        setSelectedCourseId(courseList[0].id);
      }
    };
    fetchCourses();
  }, [selectedClassId]);

  // Load students and marked attendance for the session
  const loadSessionRoster = async (currentSession: AttendanceSession) => {
    try {
      // 1. Fetch all active students in class
      const { data: studentsData, error: stErr } = await supabase
        .from('students')
        .select('*')
        .eq('class_id', currentSession.class_id)
        .eq('is_active', true)
        .order('roll_number', { ascending: true });

      if (stErr) throw stErr;
      setClassStudents((studentsData || []) as Student[]);

      // 2. Fetch existing attendance records
      const { data: recordsData, error: recErr } = await supabase
        .from('attendance')
        .select('*, students(full_name, roll_number, email)')
        .eq('session_id', currentSession.id);

      if (recErr) throw recErr;

      const map = new Map<string, AttendanceRecord>();
      (recordsData || []).forEach((r: any) => {
        map.set(r.student_id, {
          ...r,
          student: r.students,
        });
      });
      setAttendanceMap(map);
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    }
  };

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  // Realtime subscription setup
  useEffect(() => {
    if (!session || !isSupabaseConfigured) return;

    // Refetch authoritative state helper
    const refetchAuthoritativeState = async () => {
      const { data: updatedSession } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .eq('id', session.id)
        .single();

      if (updatedSession) {
        setSession({
          ...updatedSession,
          course: updatedSession.courses,
          class: updatedSession.classes,
        });
      }

      const { data: recData } = await supabase
        .from('attendance')
        .select('*, students(full_name, roll_number, email)')
        .eq('session_id', session.id);

      if (recData) {
        setAttendanceMap((prev) => {
          const next = new Map(prev);
          recData.forEach((r: any) => {
            next.set(r.student_id, {
              ...r,
              student: r.students,
            });
          });
          return next;
        });
      }
    };

    // Postgres changes channel
    const channel = supabase
      .channel(`live-session-${session.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'attendance',
          filter: `session_id=eq.${session.id}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            const newRecord = payload.new as AttendanceRecord;
            setAttendanceMap((prev) => {
              const next = new Map(prev);
              const existing = next.get(newRecord.student_id);
              next.set(newRecord.student_id, {
                ...newRecord,
                student: existing?.student,
              });
              return next;
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'attendance_sessions',
          filter: `id=eq.${session.id}`,
        },
        (payload) => {
          const updated = payload.new as AttendanceSession;
          setSession((prev) => (prev ? { ...prev, ...updated } : prev));
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          refetchAuthoritativeState();
        }
      });

    // Window focus and visibility change listeners
    const handleFocusOrVisible = () => {
      if (document.visibilityState === 'visible') {
        refetchAuthoritativeState();
      }
    };

    window.addEventListener('focus', handleFocusOrVisible);
    document.addEventListener('visibilitychange', handleFocusOrVisible);

    return () => {
      supabase.removeChannel(channel);
      window.removeEventListener('focus', handleFocusOrVisible);
      document.removeEventListener('visibilitychange', handleFocusOrVisible);
    };
  }, [session?.id]);

  // Live timer interval using synchronized server clock
  useEffect(() => {
    if (!session || session.status !== 'OPEN') return;

    const updateTimer = () => {
      const now = getServerTime().getTime();
      const expires = new Date(session.expires_at).getTime();
      const remaining = expires - now;

      if (remaining <= 0) {
        setTimeRemainingMs(0);
        setIsExpired(true);
      } else {
        setTimeRemainingMs(remaining);
        setIsExpired(false);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [session?.expires_at, session?.status]);

  // 1. Open Session RPC
  const handleOpenSession = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClassId || !selectedCourseId) {
      toastError('Please select both a class and course.');
      return;
    }
    setActionLoading(true);

    try {
      const { data, error: rpcErr } = await supabase.rpc('open_session', {
        p_class_id: selectedClassId,
        p_course_id: selectedCourseId,
        p_duration_minutes: durationMinutes,
        p_late_after_minutes: lateMinutes,
      });

      if (rpcErr) throw rpcErr;

      success('Attendance session opened successfully.');

      // Load full session with joined names
      const { data: fullData } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .eq('id', data.id)
        .single();

      if (fullData) {
        const opened: AttendanceSession = {
          ...fullData,
          course: fullData.courses,
          class: fullData.classes,
        };
        setSession(opened);
        await loadSessionRoster(opened);
      }
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  // 2. Manual attendance correction (set_attendance RPC)
  const handleManualStatusChange = async (studentId: string, newStatus: AttendanceStatus) => {
    if (!session) return;
    try {
      const { data, error: rpcErr } = await supabase.rpc('set_attendance', {
        p_session_id: session.id,
        p_student_id: studentId,
        p_status: newStatus,
      });

      if (rpcErr) throw rpcErr;

      setAttendanceMap((prev) => {
        const next = new Map(prev);
        const existing = next.get(studentId);
        next.set(studentId, {
          ...data,
          student: existing?.student,
        });
        return next;
      });

      success(`Updated status to ${newStatus}.`);
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    }
  };

  // 3. Close Session RPC (finalize)
  const handleCloseSession = async () => {
    if (!session) return;
    setActionLoading(true);
    try {
      const { error: rpcErr } = await supabase.rpc('close_session', {
        p_session_id: session.id,
      });

      if (rpcErr) throw rpcErr;

      success('Session finalized. Unmarked active students recorded as Absent.');
      setCloseConfirmOpen(false);

      // Refresh session
      const { data: updated } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .eq('id', session.id)
        .single();

      if (updated) {
        setSession({
          ...updated,
          course: updated.courses,
          class: updated.classes,
        });
        await loadSessionRoster(updated);
      }
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  // 4. Cancel Session RPC
  const handleCancelSession = async () => {
    if (!session) return;
    setActionLoading(true);
    try {
      const { error: rpcErr } = await supabase.rpc('cancel_session', {
        p_session_id: session.id,
      });

      if (rpcErr) throw rpcErr;

      info('Attendance session was cancelled.');
      setCancelConfirmOpen(false);

      const { data: updated } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .eq('id', session.id)
        .single();

      if (updated) {
        setSession({
          ...updated,
          course: updated.courses,
          class: updated.classes,
        });
      }
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <CardSkeleton />
        <TableSkeleton rows={5} columns={5} />
      </div>
    );
  }

  if (error) {
    return <ErrorState message={error} onRetry={loadInitialData} />;
  }

  // Count metrics
  let presentCount = 0;
  let lateCount = 0;
  let absentCount = 0;
  attendanceMap.forEach((rec) => {
    if (rec.status === 'PRESENT') presentCount++;
    else if (rec.status === 'LATE') lateCount++;
    else if (rec.status === 'ABSENT') absentCount++;
  });
  const totalEnrolled = classStudents.length;
  const unmarkedCount = Math.max(0, totalEnrolled - (presentCount + lateCount + absentCount));

  return (
    <div className="space-y-6">
      {/* 1. When NO session is open */}
      {!session || session.status !== 'OPEN' ? (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Live Attendance</h1>
              <p className="text-sm text-[#5B6675]">
                Launch a time-limited attendance window for your class roster.
              </p>
            </div>
            {session && session.status !== 'OPEN' && (
              <span className="text-xs px-2.5 py-1 rounded bg-[#F1F3F5] text-[#5B6675] border border-[#E2E5EA]">
                Last Session: {session.status}
              </span>
            )}
          </div>

          {/* Session Configuration Card */}
          <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-6 shadow-sm max-w-xl">
            <h2 className="text-base font-semibold text-[#1B2430] mb-4 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#1F3A5F]" />
              <span>Configure New Session</span>
            </h2>

            <form onSubmit={handleOpenSession} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#1B2430] uppercase tracking-wider mb-1">
                  Target Class
                </label>
                <select
                  value={selectedClassId}
                  onChange={(e) => {
                    setSelectedClassId(e.target.value);
                    setSelectedCourseId('');
                  }}
                  className="w-full px-3 py-2 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F]"
                >
                  {classes.map((cls) => (
                    <option key={cls.id} value={cls.id}>
                      {cls.name} ({cls.code}) {!cls.is_active ? '(Inactive)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1B2430] uppercase tracking-wider mb-1">
                  Course
                </label>
                <select
                  value={selectedCourseId}
                  onChange={(e) => setSelectedCourseId(e.target.value)}
                  disabled={courses.length === 0}
                  className="w-full px-3 py-2 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] disabled:opacity-50"
                >
                  {courses.length === 0 ? (
                    <option value="">No active courses in this class</option>
                  ) : (
                    courses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.course_name} ({c.course_code})
                      </option>
                    ))
                  )}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1B2430] uppercase tracking-wider mb-1">
                    Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={120}
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(parseInt(e.target.value, 10) || 1)}
                    className="w-full px-3 py-2 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] tabular-nums focus:ring-2 focus:ring-[#1F3A5F]"
                  />
                  <span className="text-[11px] text-[#5B6675]">1 to 120 minutes</span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1B2430] uppercase tracking-wider mb-1">
                    Late After (Minutes)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={durationMinutes}
                    value={lateMinutes}
                    onChange={(e) => setLateMinutes(parseInt(e.target.value, 10) || 0)}
                    className="w-full px-3 py-2 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] tabular-nums focus:ring-2 focus:ring-[#1F3A5F]"
                  />
                  <span className="text-[11px] text-[#5B6675]">Marks as Late after this</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={actionLoading || !selectedClassId || !selectedCourseId || courses.length === 0}
                  className="w-full py-2.5 px-4 rounded-[6px] bg-[#1F3A5F] text-white text-sm font-semibold hover:bg-[#162a45] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  <Radio className="w-4 h-4 text-white" />
                  <span>{actionLoading ? 'Opening Session...' : 'Open Attendance Session'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* If there was a closed session viewed previously */}
          {session && session.status === 'CLOSED' && (
            <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-5">
              <div className="flex items-center justify-between pb-3 border-b border-[#E2E5EA] mb-4">
                <div>
                  <h3 className="font-semibold text-sm text-[#1B2430]">
                    Finalized Roster: {session.course?.course_name}
                  </h3>
                  <p className="text-xs text-[#5B6675]">Closed at {session.closed_at ? new Date(session.closed_at).toLocaleTimeString() : 'N/A'}</p>
                </div>
                <StatusChip status="CLOSED" />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA]">
                    <tr>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Roll No</th>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Full Name</th>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Status</th>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Marked At</th>
                      <th className="p-2.5 font-semibold text-[#1B2430]">Correction</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#E2E5EA]">
                    {classStudents.map((st) => {
                      const rec = attendanceMap.get(st.id);
                      return (
                        <tr key={st.id}>
                          <td className="p-2.5 font-medium tabular-nums">{st.roll_number}</td>
                          <td className="p-2.5 font-semibold text-[#1B2430]">{st.full_name}</td>
                          <td className="p-2.5">
                            <StatusChip status={rec ? rec.status : 'ABSENT'} />
                          </td>
                          <td className="p-2.5 text-[#5B6675] tabular-nums">
                            {rec ? new Date(rec.marked_at).toLocaleTimeString() : 'Auto-absent'}
                          </td>
                          <td className="p-2.5">
                            <select
                              value={rec?.status || 'ABSENT'}
                              onChange={(e) => handleManualStatusChange(st.id, e.target.value as AttendanceStatus)}
                              className="text-xs px-2 py-1 rounded border border-[#E2E5EA] bg-white text-[#1B2430]"
                            >
                              <option value="PRESENT">Present</option>
                              <option value="LATE">Late</option>
                              <option value="ABSENT">Absent</option>
                            </select>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* 2. When session is OPEN */
        <div className="space-y-6">
          {/* Top Session Control Header */}
          <div className="bg-[#FFFFFF] border-2 border-[#1F3A5F] rounded-[6px] p-6 shadow-sm">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-[#E2E5EA]">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <StatusChip status="OPEN" />
                  <span className="text-xs text-[#5B6675]">Session ID: {session.id.substring(0, 8)}...</span>
                </div>
                <h1 className="text-xl font-bold text-[#1B2430]">
                  {session.course?.course_name} ({session.course?.course_code})
                </h1>
                <p className="text-xs text-[#5B6675]">
                  Class: <strong>{session.class?.name}</strong> • Opened at{' '}
                  {new Date(session.opened_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>

              {/* Countdown / Expiration Display */}
              <div className="flex flex-col items-start lg:items-end">
                {isExpired ? (
                  <div className="p-3 bg-[#FDF0EF] border border-[#F8CBC8] rounded-[6px] text-center">
                    <span className="text-xs font-semibold uppercase text-[#B3261E] block">
                      Session Expired
                    </span>
                    <span className="text-xs text-[#B3261E] font-medium">
                      Close session to finalize unmarked absentees
                    </span>
                  </div>
                ) : (
                  <div className="text-left lg:text-right">
                    <span className="text-xs font-medium uppercase tracking-wider text-[#5B6675] block">
                      Time Remaining
                    </span>
                    <span className="text-3xl font-bold font-mono text-[#1F3A5F] tabular-nums">
                      {formatTimeRemaining(timeRemainingMs)}
                    </span>
                    <span className="text-xs text-[#A15C00] block mt-0.5">
                      Late after: {new Date(session.late_after).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Metrics Ticker */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-b border-[#E2E5EA] text-center">
              <div className="p-3 bg-[#EAF5EF] rounded-[4px]">
                <span className="text-xs font-semibold text-[#1E7B4F] uppercase tracking-wider block">Present</span>
                <span className="text-2xl font-bold tabular-nums text-[#1E7B4F]">{presentCount}</span>
              </div>
              <div className="p-3 bg-[#FDF6EC] rounded-[4px]">
                <span className="text-xs font-semibold text-[#A15C00] uppercase tracking-wider block">Late</span>
                <span className="text-2xl font-bold tabular-nums text-[#A15C00]">{lateCount}</span>
              </div>
              <div className="p-3 bg-[#F1F3F5] rounded-[4px]">
                <span className="text-xs font-semibold text-[#5B6675] uppercase tracking-wider block">Unmarked</span>
                <span className="text-2xl font-bold tabular-nums text-[#1B2430]">{unmarkedCount}</span>
              </div>
              <div className="p-3 bg-[#F7F8FA] rounded-[4px]">
                <span className="text-xs font-semibold text-[#5B6675] uppercase tracking-wider block">Enrolled</span>
                <span className="text-2xl font-bold tabular-nums text-[#1B2430]">{totalEnrolled}</span>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4">
              <div className="text-xs text-[#5B6675] flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#1E7B4F] animate-ping" />
                <span>Roster updating live via database changes</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCancelConfirmOpen(true)}
                  disabled={actionLoading}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-[6px] border border-[#E2E5EA] text-[#5B6675] hover:text-[#B3261E] hover:bg-[#FDF0EF] transition-colors"
                >
                  Cancel Session
                </button>
                <button
                  type="button"
                  onClick={() => setCloseConfirmOpen(true)}
                  disabled={actionLoading}
                  className={`px-4 py-2 text-xs font-semibold rounded-[6px] text-white transition-colors flex items-center gap-1.5 ${
                    isExpired
                      ? 'bg-[#B3261E] hover:bg-[#971E17] animate-pulse'
                      : 'bg-[#1F3A5F] hover:bg-[#162a45]'
                  }`}
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>{isExpired ? 'Close to Finalize' : 'Finalize & Close Session'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Realtime Attendance Roster */}
          <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
            <div className="p-4 border-b border-[#E2E5EA] flex items-center justify-between">
              <h2 className="text-base font-semibold text-[#1B2430]">
                Class Roster ({classStudents.length} Students)
              </h2>
              <span className="text-xs text-[#5B6675]">
                {presentCount + lateCount} of {totalEnrolled} marked (
                {totalEnrolled > 0 ? Math.round(((presentCount + lateCount) / totalEnrolled) * 100) : 0}%)
              </span>
            </div>

            {/* Desktop Table (>=640px) */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-left text-sm border-collapse">
                <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] text-xs font-semibold text-[#5B6675] uppercase tracking-wider">
                  <tr>
                    <th className="p-3.5">Roll No</th>
                    <th className="p-3.5">Full Name</th>
                    <th className="p-3.5">Current Status</th>
                    <th className="p-3.5">Marked Time</th>
                    <th className="p-3.5">Source</th>
                    <th className="p-3.5 text-right">Teacher Override</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E2E5EA]">
                  {classStudents.map((student) => {
                    const record = attendanceMap.get(student.id);
                    return (
                      <tr key={student.id} className="hover:bg-[#F7F8FA] transition-colors">
                        <td className="p-3.5 font-mono font-medium text-[#1B2430] tabular-nums">
                          {student.roll_number}
                        </td>
                        <td className="p-3.5 font-semibold text-[#1B2430]">{student.full_name}</td>
                        <td className="p-3.5">
                          <StatusChip status={record ? record.status : 'UNMARKED'} />
                        </td>
                        <td className="p-3.5 text-xs text-[#5B6675] tabular-nums">
                          {record ? new Date(record.marked_at).toLocaleTimeString() : '—'}
                        </td>
                        <td className="p-3.5 text-xs text-[#5B6675]">
                          {record ? record.source : '—'}
                        </td>
                        <td className="p-3.5 text-right">
                          <select
                            value={record?.status || ''}
                            onChange={(e) => {
                              if (e.target.value) {
                                handleManualStatusChange(student.id, e.target.value as AttendanceStatus);
                              }
                            }}
                            className="text-xs px-2 py-1 rounded border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] focus:ring-1 focus:ring-[#1F3A5F]"
                          >
                            <option value="">Set Override...</option>
                            <option value="PRESENT">Mark Present</option>
                            <option value="LATE">Mark Late</option>
                            <option value="ABSENT">Mark Absent</option>
                          </select>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile Card List (<640px) */}
            <div className="sm:hidden divide-y divide-[#E2E5EA]">
              {classStudents.map((student) => {
                const record = attendanceMap.get(student.id);
                return (
                  <div key={student.id} className="p-4 flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold text-sm text-[#1B2430]">{student.full_name}</div>
                      <StatusChip status={record ? record.status : 'UNMARKED'} />
                    </div>
                    <div className="flex items-center justify-between text-xs text-[#5B6675]">
                      <span className="font-mono tabular-nums">Roll: {student.roll_number}</span>
                      <span>{record ? `Marked ${new Date(record.marked_at).toLocaleTimeString()}` : 'Not marked yet'}</span>
                    </div>
                    <div className="pt-1 flex justify-end">
                      <select
                        value={record?.status || ''}
                        onChange={(e) => {
                          if (e.target.value) {
                            handleManualStatusChange(student.id, e.target.value as AttendanceStatus);
                          }
                        }}
                        className="text-xs px-2 py-1 rounded border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430]"
                      >
                        <option value="">Set Override...</option>
                        <option value="PRESENT">Present</option>
                        <option value="LATE">Late</option>
                        <option value="ABSENT">Absent</option>
                      </select>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Close Confirmation Dialog */}
          <ConfirmDialog
            isOpen={closeConfirmOpen}
            title="Finalize & Close Session?"
            description={`Closing this session will permanently mark all ${unmarkedCount} currently unmarked active students as ABSENT. This action updates student percentages.`}
            confirmLabel="Close & Record Absentees"
            isLoading={actionLoading}
            onConfirm={handleCloseSession}
            onClose={() => setCloseConfirmOpen(false)}
          />

          {/* Cancel Confirmation Dialog */}
          <ConfirmDialog
            isOpen={cancelConfirmOpen}
            title="Cancel Attendance Session?"
            description="Cancelled sessions are permanently excluded from attendance percentages and reports. Student marks from this session will be discarded."
            confirmLabel="Cancel Session"
            isDestructive={true}
            isLoading={actionLoading}
            onConfirm={handleCancelSession}
            onClose={() => setCancelConfirmOpen(false)}
          />
        </div>
      )}
    </div>
  );
};
