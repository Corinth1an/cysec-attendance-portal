// src/pages/teacher/TeacherReports.tsx
// Comprehensive reports: student-wise, course-wise, date-wise stats, <75% low attendance alerts, and neutralized CSV export

import React, { useEffect, useState } from 'react';
import { Download, AlertTriangle, FileSpreadsheet, Users, BookOpen, Calendar, Filter } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { ClassItem, Course, StudentCourseStat } from '../../types/database';
import { exportToCSV } from '../../lib/csv';
import { TableSkeleton } from '../../components/common/SkeletonLoader';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorState } from '../../components/common/ErrorState';

type ReportTab = 'student' | 'course';

export const TeacherReports: React.FC = () => {
  const { user } = useAuth();

  const [activeTab, setActiveTab] = useState<ReportTab>('student');
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('all');
  const [stats, setStats] = useState<StudentCourseStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load teacher classes
  useEffect(() => {
    if (!user || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    const fetchClasses = async () => {
      try {
        const { data, error: clErr } = await supabase
          .from('classes')
          .select('*')
          .eq('teacher_id', user.id);

        if (clErr) throw clErr;
        const clsList = (data || []) as ClassItem[];
        setClasses(clsList);
      } catch (err: any) {
        setError(err?.message || 'Failed to load classes');
      }
    };
    fetchClasses();
  }, [user]);

  // Load stats from v_student_course_stats view
  const loadStats = async () => {
    if (!user || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);

    try {
      // Query view v_student_course_stats
      let query = supabase.from('v_student_course_stats').select('*');

      if (selectedClassId !== 'all') {
        query = query.eq('class_id', selectedClassId);
      }

      const { data: viewData, error: viewErr } = await query;
      if (viewErr) throw viewErr;

      const rawStats = (viewData || []) as StudentCourseStat[];

      if (rawStats.length === 0) {
        setStats([]);
        setLoading(false);
        return;
      }

      // Fetch student details and course details to enrich view
      const studentIds = Array.from(new Set(rawStats.map((s) => s.student_id)));
      const courseIds = Array.from(new Set(rawStats.map((s) => s.course_id)));

      const { data: studentsData } = await supabase
        .from('students')
        .select('id, full_name, roll_number')
        .in('id', studentIds);

      const { data: coursesData } = await supabase
        .from('courses')
        .select('id, course_name, course_code')
        .in('id', courseIds);

      const studentMap = new Map((studentsData || []).map((s) => [s.id, s]));
      const courseMap = new Map((coursesData || []).map((c) => [c.id, c]));

      const enriched: StudentCourseStat[] = rawStats.map((item) => {
        const st = studentMap.get(item.student_id);
        const co = courseMap.get(item.course_id);
        return {
          ...item,
          student_name: st?.full_name || 'Unknown',
          roll_number: st?.roll_number || '—',
          course_name: co?.course_name || 'Unknown',
          course_code: co?.course_code || '—',
        };
      });

      setStats(enriched);
    } catch (err: any) {
      setError(err?.message || 'Failed to load attendance report view');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, [selectedClassId]);

  // Export to CSV with Formula Injection Neutralization
  const handleExportCSV = () => {
    const filename = `attendance-report-${selectedClassId !== 'all' ? selectedClassId : 'all'}-${
      new Date().toISOString().split('T')[0]
    }`;

    if (activeTab === 'student') {
      const headers = [
        'Roll Number',
        'Student Name',
        'Course Code',
        'Course Name',
        'Present Count',
        'Late Count',
        'Absent Count',
        'Total Sessions',
        'Attendance %',
      ];
      const rows = stats.map((s) => [
        s.roll_number,
        s.student_name,
        s.course_code,
        s.course_name,
        s.present_count,
        s.late_count,
        s.absent_count,
        s.total_sessions,
        `${s.attendance_pct}%`,
      ]);
      exportToCSV(filename, headers, rows);
    } else {
      // Course-aggregated
      const courseAgg = getCourseAggregatedStats();
      const headers = [
        'Course Code',
        'Course Name',
        'Total Enrolled Records',
        'Total Present',
        'Total Late',
        'Total Absent',
        'Average Attendance %',
      ];
      const rows = courseAgg.map((c) => [
        c.course_code,
        c.course_name,
        c.records_count,
        c.total_present,
        c.total_late,
        c.total_absent,
        `${c.avg_pct}%`,
      ]);
      exportToCSV(`${filename}-by-course`, headers, rows);
    }
  };

  const getCourseAggregatedStats = () => {
    const map = new Map<
      string,
      {
        course_id: string;
        course_code: string;
        course_name: string;
        records_count: number;
        total_present: number;
        total_late: number;
        total_absent: number;
        total_sessions: number;
      }
    >();

    stats.forEach((s) => {
      const existing = map.get(s.course_id);
      if (existing) {
        existing.records_count += 1;
        existing.total_present += Number(s.present_count);
        existing.total_late += Number(s.late_count);
        existing.total_absent += Number(s.absent_count);
        existing.total_sessions += Number(s.total_sessions);
      } else {
        map.set(s.course_id, {
          course_id: s.course_id,
          course_code: s.course_code || '—',
          course_name: s.course_name || '—',
          records_count: 1,
          total_present: Number(s.present_count),
          total_late: Number(s.late_count),
          total_absent: Number(s.absent_count),
          total_sessions: Number(s.total_sessions),
        });
      }
    });

    return Array.from(map.values()).map((c) => {
      const validTotal = c.total_present + c.total_late + c.total_absent;
      const avg_pct =
        validTotal > 0 ? Math.round(((c.total_present + c.total_late) / validTotal) * 1000) / 10 : 0;
      return { ...c, avg_pct };
    });
  };

  const courseAggregated = getCourseAggregatedStats();
  const lowAttendanceCount = stats.filter((s) => Number(s.attendance_pct) < 75.0).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Attendance Analytics</h1>
          <p className="text-sm text-[#5B6675]">
            Official statistics computed from closed sessions. Cancelled sessions excluded.
          </p>
        </div>
        <button
          onClick={handleExportCSV}
          disabled={stats.length === 0}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] transition-colors disabled:opacity-50 self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV (Formula-Safe)</span>
        </button>
      </div>

      {/* Low attendance warning notice */}
      {lowAttendanceCount > 0 && (
        <div className="p-3.5 rounded-[6px] bg-[#FDF0EF] border border-[#F8CBC8] text-xs text-[#B3261E] flex items-center gap-2.5">
          <AlertTriangle className="w-4 h-4 shrink-0 text-[#B3261E]" />
          <span>
            <strong>{lowAttendanceCount}</strong> record{lowAttendanceCount === 1 ? '' : 's'} fall below the 75% attendance threshold. These are highlighted in red below.
          </span>
        </div>
      )}

      {/* Filter and Tab Bar */}
      <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        {/* Tabs */}
        <div className="flex items-center bg-[#F1F3F5] p-1 rounded-[6px]">
          <button
            onClick={() => setActiveTab('student')}
            className={`px-3 py-1.5 text-xs font-semibold rounded transition-colors ${
              activeTab === 'student'
                ? 'bg-[#FFFFFF] text-[#1F3A5F] shadow-xs'
                : 'text-[#5B6675] hover:text-[#1B2430]'
            }`}
          >
            Student-Wise Roster
          </button>
          <button
            onClick={() => setActiveTab('course')}
            className={`px-3 py-1.5 text-xs font-semibold rounded transition-colors ${
              activeTab === 'course'
                ? 'bg-[#FFFFFF] text-[#1F3A5F] shadow-xs'
                : 'text-[#5B6675] hover:text-[#1B2430]'
            }`}
          >
            Course Summary
          </button>
        </div>

        {/* Class Filter */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-[#5B6675] uppercase">Class:</label>
          <select
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded border border-[#E2E5EA] bg-white text-[#1B2430]"
          >
            <option value="all">All Classes</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Reports Table */}
      {loading ? (
        <TableSkeleton rows={5} columns={6} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadStats} />
      ) : stats.length === 0 ? (
        <EmptyState
          title="No completed sessions yet"
          description="Attendance statistics appear here once sessions are closed and finalized."
        />
      ) : activeTab === 'student' ? (
        /* Student-wise View */
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] text-xs font-semibold text-[#5B6675] uppercase tracking-wider">
                <tr>
                  <th className="p-3.5">Roll No</th>
                  <th className="p-3.5">Student</th>
                  <th className="p-3.5">Course</th>
                  <th className="p-3.5 text-center">Present</th>
                  <th className="p-3.5 text-center">Late</th>
                  <th className="p-3.5 text-center">Absent</th>
                  <th className="p-3.5 text-center">Total</th>
                  <th className="p-3.5 text-right">Attendance %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {stats.map((row, idx) => {
                  const pct = Number(row.attendance_pct);
                  const isLow = pct < 75.0;
                  return (
                    <tr
                      key={`${row.student_id}-${row.course_id}-${idx}`}
                      className={`hover:bg-[#F7F8FA] ${isLow ? 'bg-[#FDF0EF]/40' : ''}`}
                    >
                      <td className="p-3.5 font-mono font-medium text-[#1B2430] tabular-nums">
                        {row.roll_number}
                      </td>
                      <td className="p-3.5 font-semibold text-[#1B2430]">{row.student_name}</td>
                      <td className="p-3.5 text-xs text-[#5B6675]">
                        {row.course_code} - {row.course_name}
                      </td>
                      <td className="p-3.5 text-center tabular-nums text-[#1E7B4F] font-semibold">
                        {row.present_count}
                      </td>
                      <td className="p-3.5 text-center tabular-nums text-[#A15C00] font-semibold">
                        {row.late_count}
                      </td>
                      <td className="p-3.5 text-center tabular-nums text-[#B3261E] font-semibold">
                        {row.absent_count}
                      </td>
                      <td className="p-3.5 text-center tabular-nums text-[#5B6675]">
                        {row.total_sessions}
                      </td>
                      <td className="p-3.5 text-right">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold tabular-nums ${
                            isLow
                              ? 'bg-[#FDF0EF] text-[#B3261E] border border-[#F8CBC8]'
                              : 'bg-[#EAF5EF] text-[#1E7B4F]'
                          }`}
                        >
                          {pct.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Course Aggregated View */
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] text-xs font-semibold text-[#5B6675] uppercase tracking-wider">
                <tr>
                  <th className="p-3.5">Course Code</th>
                  <th className="p-3.5">Course Name</th>
                  <th className="p-3.5 text-center">Enrolled Records</th>
                  <th className="p-3.5 text-center">Total Present</th>
                  <th className="p-3.5 text-center">Total Late</th>
                  <th className="p-3.5 text-center">Total Absent</th>
                  <th className="p-3.5 text-right">Average Attendance %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {courseAggregated.map((c) => (
                  <tr key={c.course_id} className="hover:bg-[#F7F8FA]">
                    <td className="p-3.5 font-mono font-medium text-[#1F3A5F]">{c.course_code}</td>
                    <td className="p-3.5 font-semibold text-[#1B2430]">{c.course_name}</td>
                    <td className="p-3.5 text-center tabular-nums text-[#5B6675]">
                      {c.records_count}
                    </td>
                    <td className="p-3.5 text-center tabular-nums text-[#1E7B4F] font-semibold">
                      {c.total_present}
                    </td>
                    <td className="p-3.5 text-center tabular-nums text-[#A15C00] font-semibold">
                      {c.total_late}
                    </td>
                    <td className="p-3.5 text-center tabular-nums text-[#B3261E] font-semibold">
                      {c.total_absent}
                    </td>
                    <td className="p-3.5 text-right">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold tabular-nums bg-[#EDF3FA] text-[#1F3A5F]">
                        {c.avg_pct.toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
