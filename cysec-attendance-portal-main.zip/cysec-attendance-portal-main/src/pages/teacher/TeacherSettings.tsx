// src/pages/teacher/TeacherSettings.tsx
// Profile details, password update, and immutable audit log viewer (last 200 entries)

import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Shield, KeyRound, ScrollText, CheckCircle2, AlertCircle } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { AuditLog } from '../../types/database';
import { mapErrorMessage } from '../../lib/errorMapper';
import { TableSkeleton } from '../../components/common/SkeletonLoader';

const passwordSchema = z
  .object({
    password: z.string().min(10, 'Password must be at least 10 characters'),
    confirmPassword: z.string().min(1, 'Confirm your password'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });

type PasswordFormValues = z.infer<typeof passwordSchema>;

export const TeacherSettings: React.FC = () => {
  const { user, profile } = useAuth();
  const { success, error: toastError } = useToast();

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [logsLoading, setLogsLoading] = useState(true);
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
  });

  // Fetch last 200 audit logs
  useEffect(() => {
    if (!user || !isSupabaseConfigured) {
      setLogsLoading(false);
      return;
    }

    const fetchAuditLogs = async () => {
      try {
        const { data, error } = await supabase
          .from('audit_logs')
          .select('*')
          .eq('actor_id', user.id)
          .order('created_at', { ascending: false })
          .limit(200);

        if (error) throw error;
        setAuditLogs((data || []) as AuditLog[]);
      } catch (err: any) {
        toastError(mapErrorMessage(err));
      } finally {
        setLogsLoading(false);
      }
    };

    fetchAuditLogs();
  }, [user]);

  const onPasswordSubmit = async (values: PasswordFormValues) => {
    setIsUpdatingPassword(true);
    try {
      if (isSupabaseConfigured) {
        const { error } = await supabase.auth.updateUser({
          password: values.password,
        });
        if (error) throw error;
      }
      success('Password updated successfully.');
      reset();
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Account & Security</h1>
        <p className="text-sm text-[#5B6675]">Manage your credentials and review security audit trails.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profile Identity Card */}
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-6 space-y-4">
          <h2 className="text-base font-semibold text-[#1B2430] flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#1F3A5F]" />
            <span>Profile Identity</span>
          </h2>

          <div className="space-y-3 text-sm">
            <div>
              <span className="text-xs text-[#5B6675] uppercase tracking-wider block">Full Name</span>
              <span className="font-semibold text-[#1B2430]">{profile?.full_name}</span>
            </div>
            <div>
              <span className="text-xs text-[#5B6675] uppercase tracking-wider block">Email Address</span>
              <span className="font-medium text-[#1B2430]">{user?.email}</span>
            </div>
            <div>
              <span className="text-xs text-[#5B6675] uppercase tracking-wider block">Account Role</span>
              <span className="inline-flex px-2 py-0.5 rounded text-xs font-semibold bg-[#EDF3FA] text-[#1F3A5F] border border-[#D0DFEF] capitalize">
                {profile?.role}
              </span>
            </div>
            <div>
              <span className="text-xs text-[#5B6675] uppercase tracking-wider block">Account Created</span>
              <span className="text-xs text-[#5B6675]">
                {profile?.created_at ? new Date(profile.created_at).toLocaleString() : '—'}
              </span>
            </div>
          </div>
        </div>

        {/* Change Password Form */}
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-6 space-y-4">
          <h2 className="text-base font-semibold text-[#1B2430] flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-[#1F3A5F]" />
            <span>Update Password</span>
          </h2>

          <form onSubmit={handleSubmit(onPasswordSubmit)} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-[#1B2430] uppercase tracking-wider mb-1">
                New Password
              </label>
              <input
                type="password"
                placeholder="Minimum 10 characters"
                className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                  errors.password ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                }`}
                {...register('password')}
              />
              {errors.password && (
                <p className="mt-1 text-xs text-[#B3261E]">{errors.password.message}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#1B2430] uppercase tracking-wider mb-1">
                Confirm Password
              </label>
              <input
                type="password"
                placeholder="Re-enter password"
                className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                  errors.confirmPassword ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                }`}
                {...register('confirmPassword')}
              />
              {errors.confirmPassword && (
                <p className="mt-1 text-xs text-[#B3261E]">{errors.confirmPassword.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={isUpdatingPassword}
              className="w-full mt-2 py-2 px-4 rounded-[6px] bg-[#1F3A5F] text-white text-xs font-semibold hover:bg-[#162a45] transition-colors disabled:opacity-50"
            >
              {isUpdatingPassword ? 'Updating...' : 'Change Password'}
            </button>
          </form>
        </div>
      </div>

      {/* Audit Log Viewer */}
      <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
        <div className="p-4 border-b border-[#E2E5EA] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ScrollText className="w-4 h-4 text-[#1F3A5F]" />
            <h2 className="text-base font-semibold text-[#1B2430]">Security Audit Trail</h2>
          </div>
          <span className="text-xs text-[#5B6675]">Showing last {auditLogs.length} events</span>
        </div>

        {logsLoading ? (
          <TableSkeleton rows={4} columns={4} />
        ) : auditLogs.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#5B6675]">
            No audit records logged yet. Actions like session creation and corrections will appear here.
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[400px]">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] sticky top-0">
                <tr>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Timestamp</th>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Action</th>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Entity</th>
                  <th className="p-2.5 font-semibold text-[#1B2430]">Metadata Summary</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-[#F7F8FA]">
                    <td className="p-2.5 font-mono text-[#5B6675] tabular-nums whitespace-nowrap">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                    <td className="p-2.5 font-mono font-medium text-[#1F3A5F]">{log.action}</td>
                    <td className="p-2.5 text-[#5B6675] uppercase">{log.entity_type}</td>
                    <td className="p-2.5 font-mono text-[11px] text-[#5B6675] max-w-xs truncate">
                      {JSON.stringify(log.metadata)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
