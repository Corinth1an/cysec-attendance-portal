// src/pages/teacher/TeacherCourses.tsx
// Management of courses per class (add, edit, activate/deactivate)

import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { BookOpen, Plus, Edit2, Power } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Course, ClassItem } from '../../types/database';
import { mapErrorMessage } from '../../lib/errorMapper';
import { TableSkeleton } from '../../components/common/SkeletonLoader';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorState } from '../../components/common/ErrorState';

const courseSchema = z.object({
  course_name: z
    .string()
    .min(1, 'Course name is required')
    .max(100, 'Max 100 characters')
    .trim(),
  course_code: z
    .string()
    .min(1, 'Course code is required')
    .max(20, 'Max 20 characters')
    .regex(/^[A-Za-z0-9-]+$/, 'Alphanumeric and hyphens only')
    .trim(),
  is_active: z.boolean(),
});

type CourseFormValues = {
  course_name: string;
  course_code: string;
  is_active: boolean;
};

export const TeacherCourses: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError } = useToast();

  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm<CourseFormValues>({
    resolver: zodResolver(courseSchema),
    defaultValues: { is_active: true },
  });

  // Load teacher classes
  useEffect(() => {
    if (!user || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    const fetchClasses = async () => {
      try {
        const { data, error: clErr } = await supabase
          .from('classes')
          .select('*')
          .eq('teacher_id', user.id)
          .order('created_at', { ascending: false });

        if (clErr) throw clErr;
        const clsList = (data || []) as ClassItem[];
        setClasses(clsList);
        if (clsList.length > 0 && !selectedClassId) {
          setSelectedClassId(clsList[0].id);
        }
      } catch (err: any) {
        setError(mapErrorMessage(err));
      }
    };
    fetchClasses();
  }, [user]);

  // Load courses for selected class
  const loadCourses = async () => {
    if (!selectedClassId || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { data, error: coErr } = await supabase
        .from('courses')
        .select('*')
        .eq('class_id', selectedClassId)
        .order('course_code', { ascending: true });

      if (coErr) throw coErr;
      setCourses((data || []) as Course[]);
    } catch (err: any) {
      setError(mapErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedClassId) {
      loadCourses();
    }
  }, [selectedClassId]);

  const openCreateModal = () => {
    setEditingCourse(null);
    reset({ course_name: '', course_code: '', is_active: true });
    setModalOpen(true);
  };

  const openEditModal = (c: Course) => {
    setEditingCourse(c);
    setValue('course_name', c.course_name);
    setValue('course_code', c.course_code);
    setValue('is_active', c.is_active);
    setModalOpen(true);
  };

  const onSubmit = async (values: CourseFormValues) => {
    if (!selectedClassId) return;
    setIsSubmitting(true);

    try {
      if (editingCourse) {
        const { error: updateErr } = await supabase
          .from('courses')
          .update({
            course_name: values.course_name,
            course_code: values.course_code,
            is_active: values.is_active,
          })
          .eq('id', editingCourse.id);

        if (updateErr) throw updateErr;
        success('Course updated successfully.');
      } else {
        const { error: insertErr } = await supabase.from('courses').insert({
          class_id: selectedClassId,
          course_name: values.course_name,
          course_code: values.course_code,
          is_active: values.is_active,
        });

        if (insertErr) throw insertErr;
        success('Course created successfully.');
      }

      setModalOpen(false);
      await loadCourses();
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleCourseActive = async (course: Course) => {
    try {
      const { error: updateErr } = await supabase
        .from('courses')
        .update({ is_active: !course.is_active })
        .eq('id', course.id);

      if (updateErr) throw updateErr;
      success(`Course is now ${!course.is_active ? 'active' : 'inactive'}.`);
      await loadCourses();
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Courses</h1>
          <p className="text-sm text-[#5B6675]">Manage curriculum courses assigned to your classes.</p>
        </div>
        <button
          onClick={openCreateModal}
          disabled={!selectedClassId}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] transition-colors disabled:opacity-50 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Course</span>
        </button>
      </div>

      {/* Class Selector Bar */}
      <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <label htmlFor="courseClassSelect" className="text-xs font-semibold text-[#1B2430] uppercase tracking-wider shrink-0">
            Selected Class:
          </label>
          <select
            id="courseClassSelect"
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="px-3 py-1.5 text-sm rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] font-medium focus:ring-2 focus:ring-[#1F3A5F]"
          >
            {classes.map((cls) => (
              <option key={cls.id} value={cls.id}>
                {cls.name} ({cls.code})
              </option>
            ))}
          </select>
        </div>
        <div className="text-xs text-[#5B6675]">
          Active courses: <strong className="text-[#1B2430] font-semibold">{courses.filter((c) => c.is_active).length}</strong>
        </div>
      </div>

      {/* Courses List */}
      {loading ? (
        <TableSkeleton rows={3} columns={4} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadCourses} />
      ) : courses.length === 0 ? (
        <EmptyState
          title="No courses configured"
          description="Create courses for this class to begin tracking subject-wise attendance."
          actionText="Add First Course"
          onAction={openCreateModal}
        />
      ) : (
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] text-xs font-semibold text-[#5B6675] uppercase tracking-wider">
                <tr>
                  <th className="p-3.5">Course Code</th>
                  <th className="p-3.5">Course Title</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {courses.map((course) => (
                  <tr key={course.id} className="hover:bg-[#F7F8FA]">
                    <td className="p-3.5 font-mono font-medium text-[#1F3A5F]">{course.course_code}</td>
                    <td className="p-3.5 font-semibold text-[#1B2430]">{course.course_name}</td>
                    <td className="p-3.5">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${
                          course.is_active
                            ? 'bg-[#EAF5EF] text-[#1E7B4F] border border-[#C6E6D4]'
                            : 'bg-[#F1F3F5] text-[#5B6675] border border-[#E2E5EA]'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            course.is_active ? 'bg-[#1E7B4F]' : 'bg-[#5B6675]'
                          }`}
                        />
                        {course.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="p-3.5 text-right space-x-2">
                      <button
                        onClick={() => openEditModal(course)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA]"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-[#5B6675]" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => toggleCourseActive(course)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded border ${
                          course.is_active
                            ? 'border-[#E2E5EA] text-[#5B6675] hover:text-[#B3261E] hover:bg-[#FDF0EF]'
                            : 'border-[#C6E6D4] text-[#1E7B4F] bg-[#EAF5EF]'
                        }`}
                      >
                        <Power className="w-3.5 h-3.5" />
                        <span>{course.is_active ? 'Deactivate' : 'Activate'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal: Create / Edit Course */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-[1px]"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-lg p-6">
            <h2 className="text-lg font-bold text-[#1B2430] mb-4">
              {editingCourse ? 'Edit Course' : 'Add Course'}
            </h2>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Course Code
                </label>
                <input
                  type="text"
                  placeholder="e.g. CS101"
                  className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                    errors.course_code ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                  }`}
                  {...register('course_code')}
                />
                {errors.course_code && (
                  <p className="mt-1 text-xs text-[#B3261E]">{errors.course_code.message}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1">
                  Course Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Intro to Computer Science"
                  className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                    errors.course_name ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                  }`}
                  {...register('course_name')}
                />
                {errors.course_name && (
                  <p className="mt-1 text-xs text-[#B3261E]">{errors.course_name.message}</p>
                )}
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  id="course_is_active"
                  type="checkbox"
                  className="rounded border-[#E2E5EA] text-[#1F3A5F] focus:ring-[#1F3A5F]"
                  {...register('is_active')}
                />
                <label htmlFor="course_is_active" className="text-sm font-medium text-[#1B2430]">
                  Active for attendance sessions
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-[#E2E5EA]">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium rounded-[6px] border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 text-sm font-medium rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : editingCourse ? 'Save Changes' : 'Create Course'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
