// src/pages/auth/Login.tsx
// Secure login page: no public signup, min 10-char password, generic login error

import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Lock, Mail, AlertCircle, GraduationCap, ShieldCheck } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

const loginSchema = z.object({
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email')
    .transform((val) => val.toLowerCase().trim()),
  password: z
    .string()
    .min(10, 'Password must be at least 10 characters'),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export const Login: React.FC = () => {
  const [genericError, setGenericError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user, profile, setDemoUser } = useAuth();
  const { success } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
  });

  // If already logged in, redirect
  React.useEffect(() => {
    if (user && profile) {
      if (profile.must_change_password) {
        navigate('/change-password', { replace: true });
      } else {
        const destination = profile.role === 'teacher' ? '/t' : '/s';
        navigate(destination, { replace: true });
      }
    }
  }, [user, profile, navigate]);

  const onSubmit = async (data: LoginFormValues) => {
    setGenericError(null);
    setIsSubmitting(true);

    try {
      if (!isSupabaseConfigured) {
        // Fallback for environment before Supabase URL is injected
        if (data.email.includes('teacher')) {
          setDemoUser('teacher');
          navigate('/t');
        } else {
          setDemoUser('student');
          navigate('/s');
        }
        return;
      }

      const { data: authData, error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password,
      });

      if (error || !authData.user) {
        // ALWAYS generic error: Never reveal if email exists
        setGenericError('Invalid email or password.');
        setIsSubmitting(false);
        return;
      }

      // Profile verification is handled in AuthContext listener
      success('Signed in successfully.');
    } catch (_err) {
      setGenericError('Invalid email or password.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-4 bg-[#F7F8FA]">
      <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-sm p-8">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-[6px] bg-[#1F3A5F] text-white font-bold text-xl mb-3">
            CP
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">ClassPulse</h1>
          <p className="text-sm text-[#5B6675] mt-1">
            Institutional Attendance Portal
          </p>
        </div>

        {/* Unconfigured Supabase Notice */}
        {!isSupabaseConfigured && (
          <div className="mb-6 p-4 rounded-[6px] bg-[#EDF3FA] border border-[#D0DFEF] text-xs text-[#1F3A5F]">
            <div className="flex items-center gap-1.5 font-semibold mb-1">
              <ShieldCheck className="w-4 h-4 text-[#1F3A5F]" />
              <span>Standalone / Preview Mode</span>
            </div>
            <p className="text-[#5B6675] mb-2 leading-relaxed">
              Connect your Supabase project with <code className="bg-white px-1 py-0.5 rounded border border-[#D0DFEF]">VITE_SUPABASE_URL</code> and <code className="bg-white px-1 py-0.5 rounded border border-[#D0DFEF]">VITE_SUPABASE_ANON_KEY</code>. You can test the interface now using the instant demo access below:
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setDemoUser('teacher');
                  navigate('/t');
                }}
                className="flex-1 py-1.5 px-2 text-xs font-semibold rounded bg-[#1F3A5F] text-white hover:bg-[#162a45]"
              >
                Enter as Teacher
              </button>
              <button
                type="button"
                onClick={() => {
                  setDemoUser('student');
                  navigate('/s');
                }}
                className="flex-1 py-1.5 px-2 text-xs font-semibold rounded border border-[#1F3A5F] text-[#1F3A5F] hover:bg-[#F7F8FA]"
              >
                Enter as Student
              </button>
            </div>
          </div>
        )}

        {/* Generic Error Notice */}
        {genericError && (
          <div
            role="alert"
            className="mb-6 p-3.5 rounded-[6px] bg-[#FDF0EF] border border-[#F8CBC8] text-sm text-[#B3261E] flex items-center gap-2.5"
          >
            <AlertCircle className="w-4 h-4 shrink-0 text-[#B3261E]" />
            <span>{genericError}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
          <div>
            <label
              htmlFor="email"
              className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1.5"
            >
              Email Address
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#5B6675]">
                <Mail className="w-4 h-4" />
              </div>
              <input
                id="email"
                type="email"
                autoComplete="email"
                placeholder="name@school.edu"
                className={`w-full pl-9 pr-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] placeholder-[#8E9AAB] transition-colors focus:ring-2 focus:ring-[#1F3A5F] focus:border-[#1F3A5F] ${
                  errors.email ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                }`}
                {...register('email')}
              />
            </div>
            {errors.email && (
              <p className="mt-1 text-xs text-[#B3261E]">{errors.email.message}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="password"
              className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1.5"
            >
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#5B6675]">
                <Lock className="w-4 h-4" />
              </div>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                placeholder="Minimum 10 characters"
                className={`w-full pl-9 pr-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] placeholder-[#8E9AAB] transition-colors focus:ring-2 focus:ring-[#1F3A5F] focus:border-[#1F3A5F] ${
                  errors.password ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
                }`}
                {...register('password')}
              />
            </div>
            {errors.password && (
              <p className="mt-1 text-xs text-[#B3261E]">{errors.password.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full mt-2 py-2.5 px-4 rounded-[6px] bg-[#1F3A5F] text-white text-sm font-semibold hover:bg-[#162a45] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSubmitting ? 'Authenticating...' : 'Sign In'}
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-[#E2E5EA] text-center">
          <p className="text-xs text-[#5B6675]">
            Student credentials are provided by your instructor. Public registration is disabled.
          </p>
        </div>
      </div>
    </div>
  );
};
