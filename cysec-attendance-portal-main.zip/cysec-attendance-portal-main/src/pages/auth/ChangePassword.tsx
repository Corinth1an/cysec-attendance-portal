// src/pages/auth/ChangePassword.tsx
// Forced screen when must_change_password is true. Clears flag via RPC clear_must_change_password()

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { KeyRound, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { mapErrorMessage } from '../../lib/errorMapper';

const changePasswordSchema = z
  .object({
    password: z
      .string()
      .min(10, 'New password must be at least 10 characters long'),
    confirmPassword: z.string().min(1, 'Please confirm your new password'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ['confirmPassword'],
  });

type ChangePasswordFormValues = z.infer<typeof changePasswordSchema>;

export const ChangePassword: React.FC = () => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { profile, refreshProfile } = useAuth();
  const { success } = useToast();
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ChangePasswordFormValues>({
    resolver: zodResolver(changePasswordSchema),
  });

  const onSubmit = async (data: ChangePasswordFormValues) => {
    setErrorMessage(null);
    setIsSubmitting(true);

    try {
      if (isSupabaseConfigured) {
        // 1. Update password in Supabase Auth
        const { error: updateError } = await supabase.auth.updateUser({
          password: data.password,
        });

        if (updateError) {
          throw updateError;
        }

        // 2. Clear must_change_password flag via secure RPC
        const { error: rpcError } = await supabase.rpc('clear_must_change_password');
        if (rpcError) {
          throw rpcError;
        }

        // 3. Refresh profile state
        await refreshProfile();
      }

      success('Password updated successfully.');
      navigate(profile?.role === 'teacher' ? '/t' : '/s', { replace: true });
    } catch (err: any) {
      setErrorMessage(mapErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center p-4 bg-[#F7F8FA]">
      <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-sm p-8">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-[6px] bg-[#EDF3FA] text-[#1F3A5F] mb-3">
            <KeyRound className="w-6 h-6" />
          </div>
          <h1 className="text-xl font-bold text-[#1B2430]">Change Your Password</h1>
          <p className="text-sm text-[#5B6675] mt-1">
            You must set a new secure password before accessing your account.
          </p>
        </div>

        {errorMessage && (
          <div
            role="alert"
            className="mb-6 p-3.5 rounded-[6px] bg-[#FDF0EF] border border-[#F8CBC8] text-sm text-[#B3261E] flex items-center gap-2.5"
          >
            <ShieldAlert className="w-4 h-4 shrink-0 text-[#B3261E]" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
          <div>
            <label
              htmlFor="password"
              className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1.5"
            >
              New Password
            </label>
            <input
              id="password"
              type="password"
              placeholder="Minimum 10 characters"
              className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                errors.password ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
              }`}
              {...register('password')}
            />
            {errors.password && (
              <p className="mt-1 text-xs text-[#B3261E]">{errors.password.message}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="confirmPassword"
              className="block text-xs font-medium text-[#1B2430] uppercase tracking-wider mb-1.5"
            >
              Confirm New Password
            </label>
            <input
              id="confirmPassword"
              type="password"
              placeholder="Re-enter your new password"
              className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                errors.confirmPassword ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
              }`}
              {...register('confirmPassword')}
            />
            {errors.confirmPassword && (
              <p className="mt-1 text-xs text-[#B3261E]">{errors.confirmPassword.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full mt-2 py-2.5 px-4 rounded-[6px] bg-[#1F3A5F] text-white text-sm font-semibold hover:bg-[#162a45] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSubmitting ? 'Updating Password...' : 'Save & Continue'}
          </button>
        </form>
      </div>
    </div>
  );
};
