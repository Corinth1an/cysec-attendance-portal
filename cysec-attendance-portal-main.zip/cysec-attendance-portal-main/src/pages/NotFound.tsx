// src/pages/NotFound.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import { HelpCircle, Home } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const NotFound: React.FC = () => {
  const { profile } = useAuth();
  const homePath = profile?.role === 'teacher' ? '/t' : profile?.role === 'student' ? '/s' : '/login';

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-[#F7F8FA]">
      <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-sm p-8 text-center">
        <div className="w-12 h-12 rounded-[6px] bg-[#EDF3FA] text-[#1F3A5F] flex items-center justify-center mx-auto mb-4">
          <HelpCircle className="w-6 h-6" />
        </div>
        <h1 className="text-xl font-bold text-[#1B2430] mb-2">Page Not Found</h1>
        <p className="text-sm text-[#5B6675] mb-6">
          The requested page does not exist or you may not have permission to view it.
        </p>
        <Link
          to={homePath}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] transition-colors"
        >
          <Home className="w-4 h-4" />
          <span>Return Home</span>
        </Link>
      </div>
    </div>
  );
};
