// src/pages/student/StudentAttendance.tsx
// Personal attendance records history with course filter

import React, { useEffect, useState } from 'react';
import { UserCheck, Filter } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { AttendanceRecord, Course } from '../../types/database';
import { mapErrorMessage } from '../../lib/errorMapper';
import { StatusChip } from '../../components/common/StatusChip';
import { TableSkeleton } from '../../components/common/SkeletonLoader';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorState } from '../../components/common/ErrorState';

export const StudentAttendance: React.FC = () => {
  const { student } = useAuth();

  const [records, setRecords] = useState<any[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourseId, setSelectedCourseId] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!student || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    const loadStudentData = async () => {
      setLoading(true);
      setError(null);

      try {
        // Fetch courses for student's class
        const { data: courseData } = await supabase
          .from('courses')
          .select('*')
          .eq('class_id', student.class_id);

        setCourses((courseData || []) as Course[]);

        // Fetch attendance records for this student
        const { data: attData, error: attErr } = await supabase
          .from('attendance')
          .select('*, attendance_sessions(session_date, status, courses(course_name, course_code))')
          .eq('student_id', student.id)
          .order('marked_at', { ascending: false });

        if (attErr) throw attErr;

        setRecords(attData || []);
      } catch (err: any) {
        setError(mapErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };

    loadStudentData();
  }, [student]);

  const filteredRecords = records.filter((r) => {
    if (selectedCourseId === 'all') return true;
    return r.attendance_sessions?.courses?.id === selectedCourseId;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">My Attendance History</h1>
          <p className="text-sm text-[#5B6675]">Review your attendance marks across all courses.</p>
        </div>

        {/* Course Filter */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-[#5B6675] uppercase">Filter Course:</label>
          <select
            value={selectedCourseId}
            onChange={(e) => setSelectedCourseId(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430]"
          >
            <option value="all">All Courses</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.course_code} - {c.course_name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <TableSkeleton rows={5} columns={5} />
      ) : error ? (
        <ErrorState message={error} />
      ) : filteredRecords.length === 0 ? (
        <EmptyState
          title="No attendance records"
          description="You haven't recorded attendance in any completed sessions yet."
        />
      ) : (
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] text-xs font-semibold text-[#5B6675] uppercase tracking-wider">
                <tr>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Course</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Marked At</th>
                  <th className="p-3.5">Source</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E5EA]">
                {filteredRecords.map((rec) => {
                  const sess = rec.attendance_sessions;
                  return (
                    <tr key={rec.id} className="hover:bg-[#F7F8FA]">
                      <td className="p-3.5 font-medium text-[#1B2430] tabular-nums">
                        {sess?.session_date || '—'}
                      </td>
                      <td className="p-3.5 font-semibold text-[#1B2430]">
                        {sess?.courses?.course_name} ({sess?.courses?.course_code})
                      </td>
                      <td className="p-3.5">
                        <StatusChip status={rec.status} />
                      </td>
                      <td className="p-3.5 text-xs text-[#5B6675] tabular-nums">
                        {new Date(rec.marked_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="p-3.5 text-xs text-[#5B6675]">{rec.source}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
