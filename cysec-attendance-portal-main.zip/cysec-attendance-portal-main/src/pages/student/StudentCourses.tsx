// src/pages/student/StudentCourses.tsx
// Class courses with personal attendance percentage breakdown

import React, { useEffect, useState } from 'react';
import { BookOpen, Award, CheckCircle2, Clock, XCircle } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { Course, StudentCourseStat } from '../../types/database';
import { TableSkeleton } from '../../components/common/SkeletonLoader';
import { EmptyState } from '../../components/common/EmptyState';
import { ErrorState } from '../../components/common/ErrorState';

export const StudentCourses: React.FC = () => {
  const { student } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [statsMap, setStatsMap] = useState<Map<string, StudentCourseStat>>(new Map());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!student || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    const loadCoursesAndStats = async () => {
      setLoading(true);
      setError(null);
      try {
        const { data: coData, error: coErr } = await supabase
          .from('courses')
          .select('*')
          .eq('class_id', student.class_id)
          .eq('is_active', true)
          .order('course_code', { ascending: true });

        if (coErr) throw coErr;
        setCourses((coData || []) as Course[]);

        const { data: stData } = await supabase
          .from('v_student_course_stats')
          .select('*')
          .eq('student_id', student.id);

        const map = new Map<string, StudentCourseStat>();
        (stData || []).forEach((s: any) => {
          map.set(s.course_id, s);
        });
        setStatsMap(map);
      } catch (err: any) {
        setError(err?.message || 'Failed to load courses');
      } finally {
        setLoading(false);
      }
    };

    loadCoursesAndStats();
  }, [student]);

  if (loading) {
    return (
      <div className="space-y-4">
        <TableSkeleton rows={3} columns={4} />
      </div>
    );
  }

  if (error) {
    return <ErrorState message={error} />;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Enrolled Courses</h1>
        <p className="text-sm text-[#5B6675]">Review attendance status and criteria per course.</p>
      </div>

      {courses.length === 0 ? (
        <EmptyState
          title="No courses enrolled"
          description="Your class currently does not have any active curriculum courses assigned."
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {courses.map((course) => {
            const stat = statsMap.get(course.id);
            const pct = stat ? Number(stat.attendance_pct) : 0;
            const total = stat ? Number(stat.total_sessions) : 0;
            const isLow = stat && total > 0 && pct < 75.0;

            return (
              <div
                key={course.id}
                className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-[#EDF3FA] text-[#1F3A5F]">
                      {course.course_code}
                    </span>
                    <span
                      className={`text-sm font-bold tabular-nums px-2 py-0.5 rounded ${
                        total === 0
                          ? 'text-[#5B6675] bg-[#F1F3F5]'
                          : isLow
                          ? 'text-[#B3261E] bg-[#FDF0EF]'
                          : 'text-[#1E7B4F] bg-[#EAF5EF]'
                      }`}
                    >
                      {total === 0 ? 'No sessions' : `${pct.toFixed(1)}%`}
                    </span>
                  </div>
                  <h3 className="text-base font-semibold text-[#1B2430]">{course.course_name}</h3>
                </div>

                <div className="pt-4 mt-4 border-t border-[#E2E5EA] grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 rounded bg-[#F7F8FA]">
                    <span className="text-[#5B6675] block text-[11px]">Present</span>
                    <span className="font-bold text-[#1E7B4F] tabular-nums">
                      {stat ? stat.present_count : 0}
                    </span>
                  </div>
                  <div className="p-2 rounded bg-[#F7F8FA]">
                    <span className="text-[#5B6675] block text-[11px]">Late</span>
                    <span className="font-bold text-[#A15C00] tabular-nums">
                      {stat ? stat.late_count : 0}
                    </span>
                  </div>
                  <div className="p-2 rounded bg-[#F7F8FA]">
                    <span className="text-[#5B6675] block text-[11px]">Absent</span>
                    <span className="font-bold text-[#B3261E] tabular-nums">
                      {stat ? stat.absent_count : 0}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
