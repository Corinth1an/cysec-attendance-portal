// src/pages/student/StudentDashboard.tsx
// Hero Mark Present button (56px tall on mobile), realtime session subscription, clock-skew synced countdown, and course attendance percentages

import React, { useEffect, useState, useCallback, useId } from 'react';
import {
  CheckCircle2,
  Clock,
  Radio,
  Lock,
  WifiOff,
  AlertCircle,
  BookOpen,
  Calendar,
  Layers,
} from 'lucide-react';
import { supabase, isSupabaseConfigured, getServerTime, syncServerClock } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import {
  AttendanceSession,
  AttendanceRecord,
  StudentCourseStat,
  ClassItem,
} from '../../types/database';
import { mapErrorMessage } from '../../lib/errorMapper';
import { formatTimeRemaining } from '../../lib/utils';
import { StatusChip } from '../../components/common/StatusChip';
import { CardSkeleton } from '../../components/common/SkeletonLoader';
import { ErrorState } from '../../components/common/ErrorState';

export const StudentDashboard: React.FC = () => {
  const { user, profile, student } = useAuth();
  const { success, error: toastError, info } = useToast();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [classInfo, setClassInfo] = useState<ClassItem | null>(null);
  const [activeSession, setActiveSession] = useState<AttendanceSession | null>(null);
  const [myAttendance, setMyAttendance] = useState<AttendanceRecord | null>(null);
  const [courseStats, setCourseStats] = useState<StudentCourseStat[]>([]);

  // Mutation and offline tracking
  const [isMarking, setIsMarking] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Time remaining
  const [timeRemainingMs, setTimeRemainingMs] = useState<number>(0);
  const [isLate, setIsLate] = useState<boolean>(false);
  const [isExpired, setIsExpired] = useState<boolean>(false);

  // Monitor network online / offline
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Fetch initial student class, active session, and stats
  const loadDashboardData = useCallback(async () => {
    if (!student || !isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);

    try {
      await syncServerClock();

      // 1. Fetch class info
      const { data: clsData } = await supabase
        .from('classes')
        .select('*')
        .eq('id', student.class_id)
        .single();

      if (clsData) {
        setClassInfo(clsData as ClassItem);
      }

      // 2. Fetch current OPEN session for student's class
      const { data: sessionData } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .eq('class_id', student.class_id)
        .eq('status', 'OPEN')
        .order('opened_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (sessionData) {
        const fullSession: AttendanceSession = {
          ...sessionData,
          course: sessionData.courses,
          class: sessionData.classes,
        };
        setActiveSession(fullSession);

        // Check if student already marked for this session
        const { data: markData } = await supabase
          .from('attendance')
          .select('*')
          .eq('session_id', fullSession.id)
          .eq('student_id', student.id)
          .maybeSingle();

        setMyAttendance(markData as AttendanceRecord | null);
      } else {
        setActiveSession(null);
        setMyAttendance(null);
      }

      // 3. Fetch course attendance stats from v_student_course_stats view
      const { data: statsData } = await supabase
        .from('v_student_course_stats')
        .select('*')
        .eq('student_id', student.id);

      if (statsData && statsData.length > 0) {
        const courseIds = statsData.map((s) => s.course_id);
        const { data: coursesData } = await supabase
          .from('courses')
          .select('id, course_name, course_code')
          .in('id', courseIds);

        const courseMap = new Map((coursesData || []).map((c) => [c.id, c]));
        const enriched: StudentCourseStat[] = statsData.map((s: any) => ({
          ...s,
          course_name: courseMap.get(s.course_id)?.course_name || 'Course',
          course_code: courseMap.get(s.course_id)?.course_code || '—',
        }));

        setCourseStats(enriched);
      } else {
        setCourseStats([]);
      }
    } catch (err: any) {
      setError(mapErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [student]);

  useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  // Realtime subscription: attendance_sessions for student's class
  useEffect(() => {
    if (!student || !isSupabaseConfigured) return;

    const refetchSessionState = async () => {
      const { data: sessionData } = await supabase
        .from('attendance_sessions')
        .select('*, courses(course_name, course_code), classes(name, code)')
        .eq('class_id', student.class_id)
        .eq('status', 'OPEN')
        .order('opened_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (sessionData) {
        const fullSession: AttendanceSession = {
          ...sessionData,
          course: sessionData.courses,
          class: sessionData.classes,
        };
        setActiveSession(fullSession);

        const { data: markData } = await supabase
          .from('attendance')
          .select('*')
          .eq('session_id', fullSession.id)
          .eq('student_id', student.id)
          .maybeSingle();

        setMyAttendance(markData as AttendanceRecord | null);
      } else {
        setActiveSession(null);
        setMyAttendance(null);
      }
    };

    const channel = supabase
      .channel(`student-class-${student.class_id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'attendance_sessions',
          filter: `class_id=eq.${student.class_id}`,
        },
        (_payload) => {
          refetchSessionState();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'attendance',
          filter: `student_id=eq.${student.id}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            setMyAttendance(payload.new as AttendanceRecord);
          }
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          refetchSessionState();
        }
      });

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        refetchSessionState();
      }
    };

    window.addEventListener('focus', handleVisibility);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      supabase.removeChannel(channel);
      window.removeEventListener('focus', handleVisibility);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [student?.class_id, student?.id]);

  // Synchronized countdown timer
  useEffect(() => {
    if (!activeSession || activeSession.status !== 'OPEN') return;

    const updateTimer = () => {
      const now = getServerTime().getTime();
      const expires = new Date(activeSession.expires_at).getTime();
      const lateAfter = new Date(activeSession.late_after).getTime();

      const remaining = expires - now;
      if (remaining <= 0) {
        setTimeRemainingMs(0);
        setIsExpired(true);
      } else {
        setTimeRemainingMs(remaining);
        setIsExpired(false);
      }

      setIsLate(now > lateAfter);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [activeSession?.expires_at, activeSession?.late_after, activeSession?.status]);

  // Mark Present RPC trigger
  const handleMarkPresent = async () => {
    if (!activeSession || !student || isMarking) return;
    setIsMarking(true);

    try {
      // Call mark_my_attendance RPC (identity derived strictly from auth.uid())
      const { data, error: rpcErr } = await supabase.rpc('mark_my_attendance', {
        p_session_id: activeSession.id,
      });

      if (rpcErr) {
        throw rpcErr;
      }

      setMyAttendance(data as AttendanceRecord);
      success(
        data.status === 'LATE'
          ? 'Marked attendance as LATE.'
          : 'Attendance marked PRESENT successfully!'
      );
    } catch (err: any) {
      toastError(mapErrorMessage(err));
      // In case session closed concurrently, refetch state immediately
      await loadDashboardData();
    } finally {
      setIsMarking(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <CardSkeleton />
        <CardSkeleton />
      </div>
    );
  }

  if (error) {
    return <ErrorState message={error} onRetry={loadDashboardData} />;
  }

  return (
    <div className="space-y-6">
      {/* Student Banner */}
      <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-[#5B6675]">
              Student Portal
            </span>
            <h1 className="text-xl font-bold text-[#1B2430]">{profile?.full_name}</h1>
            <p className="text-xs text-[#5B6675] mt-0.5">
              Roll No: <strong className="text-[#1B2430] font-mono">{student?.roll_number}</strong> • Class:{' '}
              <strong className="text-[#1B2430]">{classInfo?.name || 'Class'}</strong>
            </p>
          </div>
          <div className="self-start sm:self-auto">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold bg-[#EDF3FA] text-[#1F3A5F] border border-[#D0DFEF]">
              <Layers className="w-3.5 h-3.5" />
              <span>{classInfo?.code}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Hero Attendance Action Card */}
      {activeSession ? (
        <div className="bg-[#FFFFFF] border-2 border-[#1F3A5F] rounded-[6px] p-6 md:p-8 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E2E5EA]">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <StatusChip status="OPEN" />
                <span className="text-xs text-[#5B6675]">Live Class Attendance</span>
              </div>
              <h2 className="text-xl md:text-2xl font-bold text-[#1B2430]">
                {activeSession.course?.course_name}
              </h2>
              <p className="text-xs text-[#5B6675]">Course Code: {activeSession.course?.course_code}</p>
            </div>

            {/* Countdown Display */}
            <div className="text-left sm:text-right">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#5B6675] block">
                Window Closes In
              </span>
              <span className="text-2xl md:text-3xl font-bold font-mono text-[#1F3A5F] tabular-nums">
                {formatTimeRemaining(timeRemainingMs)}
              </span>
              {isLate && !myAttendance && (
                <span className="text-xs text-[#A15C00] font-medium block mt-0.5">
                  Grace period ended. Submissions will be marked LATE.
                </span>
              )}
            </div>
          </div>

          {/* Hero Button / Confirmation State */}
          <div className="pt-6">
            {myAttendance ? (
              /* Already Marked Confirmation State */
              <div
                role="status"
                aria-live="polite"
                className="p-5 rounded-[6px] bg-[#EAF5EF] border border-[#C6E6D4] flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-[#1E7B4F] text-white shrink-0">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-[#1E7B4F]">Attendance Recorded</h3>
                    <p className="text-xs text-[#1E7B4F]">
                      Status: <strong>{myAttendance.status}</strong> • Marked at{' '}
                      {new Date(myAttendance.marked_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </p>
                  </div>
                </div>
                <StatusChip status={myAttendance.status} />
              </div>
            ) : isExpired ? (
              /* Expired Notice */
              <div className="p-4 rounded-[6px] bg-[#FDF0EF] border border-[#F8CBC8] text-center text-[#B3261E]">
                <Clock className="w-5 h-5 mx-auto mb-1 text-[#B3261E]" />
                <p className="text-sm font-bold">Attendance Window Closed</p>
                <p className="text-xs">The time limit for self-marking attendance has expired.</p>
              </div>
            ) : !isOnline ? (
              /* Offline Disabled State */
              <div className="space-y-2">
                <button
                  disabled
                  className="w-full h-14 rounded-[6px] bg-[#5B6675] text-white text-base font-semibold cursor-not-allowed opacity-50 flex items-center justify-center gap-2"
                >
                  <WifiOff className="w-5 h-5" />
                  <span>Mark Present (Offline)</span>
                </button>
                <p className="text-center text-xs text-[#B3261E]">
                  You are offline. An active internet connection is required to mark attendance.
                </p>
              </div>
            ) : (
              /* Active Hero Mark Present Button (56px tall on mobile) */
              <button
                type="button"
                onClick={handleMarkPresent}
                disabled={isMarking}
                className="w-full h-14 rounded-[6px] bg-[#1F3A5F] hover:bg-[#162a45] active:scale-[0.99] text-white text-base font-bold transition-all shadow-md flex items-center justify-center gap-3 disabled:opacity-50 cursor-pointer"
              >
                <CheckCircle2 className="w-6 h-6" />
                <span>
                  {isMarking
                    ? 'Recording Attendance...'
                    : isLate
                    ? 'Mark Attendance (Late)'
                    : 'Mark Present'}
                </span>
              </button>
            )}
          </div>
        </div>
      ) : (
        /* No Session Open State */
        <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-8 text-center">
          <div className="w-12 h-12 rounded-[6px] bg-[#F1F3F5] text-[#5B6675] flex items-center justify-center mx-auto mb-3">
            <Clock className="w-6 h-6" />
          </div>
          <h2 className="text-base font-bold text-[#1B2430] mb-1">No Active Attendance Session</h2>
          <p className="text-xs text-[#5B6675] max-w-sm mx-auto leading-relaxed">
            When your teacher opens an attendance window, it will automatically appear here in realtime without needing to refresh.
          </p>
        </div>
      )}

      {/* Course Attendance Percentages */}
      <div>
        <h2 className="text-base font-semibold text-[#1B2430] mb-3 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-[#1F3A5F]" />
          <span>Your Course Attendance</span>
        </h2>

        {courseStats.length === 0 ? (
          <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-6 text-center text-xs text-[#5B6675]">
            Attendance percentages will be computed once past sessions are closed by your instructor.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {courseStats.map((st) => {
              const pct = Number(st.attendance_pct);
              const isLow = pct < 75.0;
              return (
                <div
                  key={st.course_id}
                  className={`bg-[#FFFFFF] border rounded-[6px] p-4 flex flex-col justify-between ${
                    isLow ? 'border-[#F8CBC8]' : 'border-[#E2E5EA]'
                  }`}
                >
                  <div className="mb-2">
                    <span className="text-[11px] font-mono text-[#5B6675] block uppercase">
                      {st.course_code}
                    </span>
                    <h3 className="font-semibold text-sm text-[#1B2430] truncate">{st.course_name}</h3>
                  </div>

                  <div className="pt-3 border-t border-[#E2E5EA] flex items-end justify-between">
                    <div>
                      <span className="text-[11px] text-[#5B6675] block">
                        Attended: {Number(st.present_count) + Number(st.late_count)} / {st.total_sessions}
                      </span>
                    </div>
                    <span
                      className={`text-lg font-bold tabular-nums ${
                        isLow ? 'text-[#B3261E]' : 'text-[#1E7B4F]'
                      }`}
                    >
                      {pct.toFixed(1)}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
