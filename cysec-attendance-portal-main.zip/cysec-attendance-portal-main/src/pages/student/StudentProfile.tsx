// src/pages/student/StudentProfile.tsx
// Student identity (read-only) and password change form

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { User, KeyRound, ShieldCheck } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { mapErrorMessage } from '../../lib/errorMapper';

const passwordSchema = z
  .object({
    password: z.string().min(10, 'Password must be at least 10 characters'),
    confirmPassword: z.string().min(1, 'Confirm your password'),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });

type PasswordFormValues = z.infer<typeof passwordSchema>;

export const StudentProfile: React.FC = () => {
  const { user, profile, student } = useAuth();
  const { success, error: toastError } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
  });

  const onPasswordSubmit = async (values: PasswordFormValues) => {
    setIsSubmitting(true);
    try {
      if (isSupabaseConfigured) {
        const { error } = await supabase.auth.updateUser({
          password: values.password,
        });
        if (error) throw error;
      }
      success('Password updated successfully.');
      reset();
    } catch (err: any) {
      toastError(mapErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-[#1B2430]">Student Profile</h1>
        <p className="text-sm text-[#5B6675]">View your institutional identity and update your password.</p>
      </div>

      {/* Read-Only Identity Details */}
      <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-6 space-y-4">
        <h2 className="text-base font-semibold text-[#1B2430] flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#1F3A5F]" />
          <span>Verified Student Identity</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-xs text-[#5B6675] uppercase tracking-wider block">Full Name</span>
            <span className="font-semibold text-[#1B2430]">{student?.full_name || profile?.full_name}</span>
          </div>

          <div>
            <span className="text-xs text-[#5B6675] uppercase tracking-wider block">Roll Number</span>
            <span className="font-mono font-semibold text-[#1F3A5F] tabular-nums">
              {student?.roll_number || '—'}
            </span>
          </div>

          <div>
            <span className="text-xs text-[#5B6675] uppercase tracking-wider block">Institutional Email</span>
            <span className="font-medium text-[#1B2430]">{student?.email || user?.email}</span>
          </div>

          <div>
            <span className="text-xs text-[#5B6675] uppercase tracking-wider block">Enrollment Status</span>
            <span className="inline-flex px-2 py-0.5 rounded text-xs font-semibold bg-[#EAF5EF] text-[#1E7B4F] border border-[#C6E6D4]">
              {student?.is_active ? 'Active' : 'Inactive'}
            </span>
          </div>
        </div>

        <p className="text-xs text-[#5B6675] pt-2 border-t border-[#E2E5EA]">
          Note: Name, roll number, and email are managed by your instructor and cannot be modified directly.
        </p>
      </div>

      {/* Password Update Card */}
      <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-6 space-y-4">
        <h2 className="text-base font-semibold text-[#1B2430] flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-[#1F3A5F]" />
          <span>Change Password</span>
        </h2>

        <form onSubmit={handleSubmit(onPasswordSubmit)} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#1B2430] uppercase tracking-wider mb-1">
              New Password
            </label>
            <input
              type="password"
              placeholder="Minimum 10 characters"
              className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                errors.password ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
              }`}
              {...register('password')}
            />
            {errors.password && (
              <p className="mt-1 text-xs text-[#B3261E]">{errors.password.message}</p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#1B2430] uppercase tracking-wider mb-1">
              Confirm New Password
            </label>
            <input
              type="password"
              placeholder="Re-enter new password"
              className={`w-full px-3 py-2 text-sm rounded-[6px] border bg-[#FFFFFF] text-[#1B2430] focus:ring-2 focus:ring-[#1F3A5F] ${
                errors.confirmPassword ? 'border-[#B3261E]' : 'border-[#E2E5EA]'
              }`}
              {...register('confirmPassword')}
            />
            {errors.confirmPassword && (
              <p className="mt-1 text-xs text-[#B3261E]">{errors.confirmPassword.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="py-2.5 px-4 rounded-[6px] bg-[#1F3A5F] text-white text-xs font-semibold hover:bg-[#162a45] transition-colors disabled:opacity-50"
          >
            {isSubmitting ? 'Updating...' : 'Update Password'}
          </button>
        </form>
      </div>
    </div>
  );
};
