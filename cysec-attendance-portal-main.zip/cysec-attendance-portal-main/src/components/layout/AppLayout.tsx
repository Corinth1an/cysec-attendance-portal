// src/components/layout/AppLayout.tsx
// Responsive layout: Left sidebar on >=1024px, bottom tab bar on <1024px. Max-width 1100px.

import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Radio,
  Users,
  History,
  BookOpen,
  FileSpreadsheet,
  Settings,
  LogOut,
  GraduationCap,
  Layers,
  Menu,
  X,
  UserCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { ConnectionIndicator } from '../common/ConnectionIndicator';

export const AppLayout: React.FC = () => {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);

  const isTeacher = profile?.role === 'teacher';

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const teacherNavItems = [
    { label: 'Dashboard', path: '/t', icon: LayoutDashboard },
    { label: 'Live Session', path: '/t/live', icon: Radio },
    { label: 'Classes', path: '/t/classes', icon: Layers },
    { label: 'Students', path: '/t/students', icon: Users },
    { label: 'Courses', path: '/t/courses', icon: BookOpen },
    { label: 'History', path: '/t/history', icon: History },
    { label: 'Reports', path: '/t/reports', icon: FileSpreadsheet },
    { label: 'Settings', path: '/t/settings', icon: Settings },
  ];

  const studentNavItems = [
    { label: 'Dashboard', path: '/s', icon: LayoutDashboard },
    { label: 'Attendance', path: '/s/attendance', icon: UserCheck },
    { label: 'Courses', path: '/s/courses', icon: BookOpen },
    { label: 'Profile', path: '/s/profile', icon: Settings },
  ];

  const currentNavItems = isTeacher ? teacherNavItems : studentNavItems;

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-[#F7F8FA] text-[#1B2430]">
      {/* Desktop Sidebar (>=1024px) */}
      <aside className="hidden lg:flex lg:flex-col w-64 bg-[#FFFFFF] border-r border-[#E2E5EA] shrink-0 sticky top-0 h-screen z-20">
        {/* App Title & Role */}
        <div className="p-6 border-b border-[#E2E5EA] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-[6px] bg-[#1F3A5F] text-white flex items-center justify-center font-bold text-sm">
              CP
            </div>
            <div>
              <h1 className="font-semibold text-base tracking-tight text-[#1B2430]">ClassPulse</h1>
              <span className="text-[11px] font-medium text-[#5B6675] uppercase tracking-wider">
                {isTeacher ? 'Faculty Portal' : 'Student Portal'}
              </span>
            </div>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto" aria-label="Main Navigation">
          {currentNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.path === '/t' || item.path === '/s'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-[6px] text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-[#EDF3FA] text-[#1F3A5F] font-semibold'
                      : 'text-[#5B6675] hover:bg-[#F7F8FA] hover:text-[#1B2430]'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>

        {/* User Profile & Sign Out Footer */}
        <div className="p-4 border-t border-[#E2E5EA] bg-[#FFFFFF]">
          <div className="flex items-center justify-between gap-2 mb-3">
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold truncate text-[#1B2430]">{profile?.full_name}</p>
              <p className="text-xs text-[#5B6675] capitalize truncate">{profile?.role}</p>
            </div>
            <ConnectionIndicator />
          </div>
          <button
            onClick={handleSignOut}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-[#5B6675] hover:text-[#B3261E] hover:bg-[#FDF0EF] border border-[#E2E5EA] rounded-[6px] transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 pb-16 lg:pb-0">
        {/* Mobile Header (<1024px) */}
        <header className="lg:hidden bg-[#FFFFFF] border-b border-[#E2E5EA] p-4 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-[4px] bg-[#1F3A5F] text-white flex items-center justify-center font-bold text-xs">
              CP
            </div>
            <h1 className="font-semibold text-sm tracking-tight text-[#1B2430]">ClassPulse</h1>
          </div>
          <div className="flex items-center gap-3">
            <ConnectionIndicator />
            <button
              onClick={handleSignOut}
              className="p-1.5 text-[#5B6675] hover:text-[#B3261E] rounded transition-colors"
              title="Sign Out"
              aria-label="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Primary Page Canvas (max-width 1100px) */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-[1100px] w-full mx-auto">
          <Outlet />
        </main>
      </div>

      {/* Mobile Bottom Navigation (<1024px) */}
      <nav
        className="lg:hidden fixed bottom-0 left-0 right-0 bg-[#FFFFFF] border-t border-[#E2E5EA] z-30 flex items-center justify-around h-14 px-2 shadow-sm"
        aria-label="Mobile Navigation"
      >
        {isTeacher ? (
          <>
            <NavLink
              to="/t"
              end
              className={({ isActive }) =>
                `flex flex-col items-center justify-center py-1 flex-1 text-xs font-medium ${
                  isActive ? 'text-[#1F3A5F] font-semibold' : 'text-[#5B6675]'
                }`
              }
            >
              <LayoutDashboard className="w-4 h-4 mb-0.5" />
              <span>Dashboard</span>
            </NavLink>
            <NavLink
              to="/t/live"
              className={({ isActive }) =>
                `flex flex-col items-center justify-center py-1 flex-1 text-xs font-medium ${
                  isActive ? 'text-[#1F3A5F] font-semibold' : 'text-[#5B6675]'
                }`
              }
            >
              <Radio className="w-4 h-4 mb-0.5 text-[#1F3A5F]" />
              <span>Live</span>
            </NavLink>
            <NavLink
              to="/t/students"
              className={({ isActive }) =>
                `flex flex-col items-center justify-center py-1 flex-1 text-xs font-medium ${
                  isActive ? 'text-[#1F3A5F] font-semibold' : 'text-[#5B6675]'
                }`
              }
            >
              <Users className="w-4 h-4 mb-0.5" />
              <span>Students</span>
            </NavLink>
            <NavLink
              to="/t/history"
              className={({ isActive }) =>
                `flex flex-col items-center justify-center py-1 flex-1 text-xs font-medium ${
                  isActive ? 'text-[#1F3A5F] font-semibold' : 'text-[#5B6675]'
                }`
              }
            >
              <History className="w-4 h-4 mb-0.5" />
              <span>History</span>
            </NavLink>
            <button
              onClick={() => setMobileMoreOpen(!mobileMoreOpen)}
              className={`flex flex-col items-center justify-center py-1 flex-1 text-xs font-medium ${
                mobileMoreOpen ? 'text-[#1F3A5F] font-semibold' : 'text-[#5B6675]'
              }`}
            >
              <Menu className="w-4 h-4 mb-0.5" />
              <span>More</span>
            </button>
          </>
        ) : (
          studentNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.path === '/s'}
                className={({ isActive }) =>
                  `flex flex-col items-center justify-center py-1 flex-1 text-xs font-medium ${
                    isActive ? 'text-[#1F3A5F] font-semibold' : 'text-[#5B6675]'
                  }`
                }
              >
                <Icon className="w-4 h-4 mb-0.5" />
                <span>{item.label}</span>
              </NavLink>
            );
          })
        )}
      </nav>

      {/* Mobile "More" Drawer for Teacher */}
      {mobileMoreOpen && isTeacher && (
        <div className="lg:hidden fixed inset-0 z-40 bg-black/40 flex flex-col justify-end">
          <div className="bg-[#FFFFFF] border-t border-[#E2E5EA] p-5 pb-20 rounded-t-[12px] space-y-2">
            <div className="flex items-center justify-between pb-3 border-b border-[#E2E5EA]">
              <h3 className="font-semibold text-sm text-[#1B2430]">More Options</h3>
              <button
                onClick={() => setMobileMoreOpen(false)}
                className="p-1 text-[#5B6675] hover:text-[#1B2430]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <NavLink
              to="/t/classes"
              onClick={() => setMobileMoreOpen(false)}
              className="flex items-center gap-3 p-3 text-sm font-medium text-[#1B2430] hover:bg-[#F7F8FA] rounded-[6px]"
            >
              <Layers className="w-4 h-4 text-[#5B6675]" />
              <span>Classes</span>
            </NavLink>
            <NavLink
              to="/t/courses"
              onClick={() => setMobileMoreOpen(false)}
              className="flex items-center gap-3 p-3 text-sm font-medium text-[#1B2430] hover:bg-[#F7F8FA] rounded-[6px]"
            >
              <BookOpen className="w-4 h-4 text-[#5B6675]" />
              <span>Courses</span>
            </NavLink>
            <NavLink
              to="/t/reports"
              onClick={() => setMobileMoreOpen(false)}
              className="flex items-center gap-3 p-3 text-sm font-medium text-[#1B2430] hover:bg-[#F7F8FA] rounded-[6px]"
            >
              <FileSpreadsheet className="w-4 h-4 text-[#5B6675]" />
              <span>Reports</span>
            </NavLink>
            <NavLink
              to="/t/settings"
              onClick={() => setMobileMoreOpen(false)}
              className="flex items-center gap-3 p-3 text-sm font-medium text-[#1B2430] hover:bg-[#F7F8FA] rounded-[6px]"
            >
              <Settings className="w-4 h-4 text-[#5B6675]" />
              <span>Settings</span>
            </NavLink>
          </div>
        </div>
      )}
    </div>
  );
};
