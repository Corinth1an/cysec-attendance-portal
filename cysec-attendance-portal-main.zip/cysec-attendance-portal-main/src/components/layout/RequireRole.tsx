// src/components/layout/RequireRole.tsx
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { AppRole } from '../../types/database';

interface RequireRoleProps {
  role: AppRole;
  children: React.ReactNode;
}

export const RequireRole: React.FC<RequireRoleProps> = ({ role, children }) => {
  const { profile, isLoading } = useAuth();

  if (isLoading) {
    return null;
  }

  if (profile?.role !== role) {
    // Redirect to correct dashboard based on actual role
    return <Navigate to={profile?.role === 'teacher' ? '/t' : '/s'} replace />;
  }

  return <>{children}</>;
};
