// src/components/common/StatCard.tsx
import React from 'react';

interface StatCardProps {
  label: string;
  value: string | number;
  subtext?: string;
  icon?: React.ReactNode;
  highlight?: 'normal' | 'warning' | 'success';
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  subtext,
  icon,
  highlight = 'normal',
}) => {
  return (
    <div className="bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] p-5 flex flex-col justify-between">
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-xs font-medium uppercase tracking-wider text-[#5B6675]">
          {label}
        </span>
        {icon && <div className="text-[#5B6675]">{icon}</div>}
      </div>
      <div>
        <div
          className={`text-2xl font-semibold tabular-nums ${
            highlight === 'warning'
              ? 'text-[#B3261E]'
              : highlight === 'success'
              ? 'text-[#1E7B4F]'
              : 'text-[#1B2430]'
          }`}
        >
          {value}
        </div>
        {subtext && (
          <p className="text-xs text-[#5B6675] mt-1 font-normal">{subtext}</p>
        )}
      </div>
    </div>
  );
};
