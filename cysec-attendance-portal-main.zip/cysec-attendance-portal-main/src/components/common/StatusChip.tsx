// src/components/common/StatusChip.tsx
// Status is never conveyed by color alone: always chip = icon + text label.

import React from 'react';
import { CheckCircle2, Clock, XCircle, Radio, Lock, AlertTriangle } from 'lucide-react';
import { AttendanceStatus, SessionStatus } from '../../types/database';

interface StatusChipProps {
  status: AttendanceStatus | SessionStatus | 'CANCELLED' | 'UNMARKED';
  className?: string;
}

export const StatusChip: React.FC<StatusChipProps> = ({ status, className = '' }) => {
  switch (status) {
    case 'PRESENT':
      return (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-semibold bg-[#EAF5EF] text-[#1E7B4F] border border-[#C6E6D4] ${className}`}
        >
          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>Present</span>
        </span>
      );

    case 'LATE':
      return (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-semibold bg-[#FDF6EC] text-[#A15C00] border border-[#F6E1C4] ${className}`}
        >
          <Clock className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>Late</span>
        </span>
      );

    case 'ABSENT':
      return (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-semibold bg-[#FDF0EF] text-[#B3261E] border border-[#F8CBC8] ${className}`}
        >
          <XCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>Absent</span>
        </span>
      );

    case 'OPEN':
      return (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-semibold bg-[#EDF3FA] text-[#1F3A5F] border border-[#D0DFEF] ${className}`}
        >
          <Radio className="w-3.5 h-3.5 shrink-0 animate-pulse text-[#1F3A5F]" aria-hidden="true" />
          <span>Open Session</span>
        </span>
      );

    case 'CLOSED':
      return (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-semibold bg-[#F1F3F5] text-[#5B6675] border border-[#E2E5EA] ${className}`}
        >
          <Lock className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>Closed</span>
        </span>
      );

    case 'CANCELLED':
      return (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-semibold bg-[#F5F5F5] text-[#71717A] border border-[#E4E4E7] ${className}`}
        >
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>Cancelled</span>
        </span>
      );

    case 'UNMARKED':
    default:
      return (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-medium bg-[#F1F3F5] text-[#5B6675] border border-[#E2E5EA] ${className}`}
        >
          <span className="w-2 h-2 rounded-full bg-[#8E9AAB] shrink-0" aria-hidden="true" />
          <span>Not marked</span>
        </span>
      );
  }
};
