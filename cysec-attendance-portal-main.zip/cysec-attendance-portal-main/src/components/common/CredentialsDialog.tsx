// src/components/common/CredentialsDialog.tsx
// Displays student temporary credentials once with CSV download and clear warning

import React from 'react';
import { Download, AlertTriangle, CheckCircle2, X } from 'lucide-react';
import { exportToCSV } from '../../lib/csv';

export interface CredentialResult {
  full_name: string;
  roll_number: string;
  email: string;
  status: 'created' | 'failed';
  temp_password?: string;
  error?: string;
}

interface CredentialsDialogProps {
  isOpen: boolean;
  credentials: CredentialResult[];
  onClose: () => void;
}

export const CredentialsDialog: React.FC<CredentialsDialogProps> = ({
  isOpen,
  credentials,
  onClose,
}) => {
  if (!isOpen) return null;

  const successfulCreds = credentials.filter((c) => c.status === 'created' && c.temp_password);

  const handleDownload = () => {
    const headers = ['Full Name', 'Roll Number', 'Email', 'Temporary Password'];
    const rows = successfulCreds.map((c) => [
      c.full_name,
      c.roll_number,
      c.email,
      c.temp_password || '',
    ]);
    exportToCSV(`student-credentials-${new Date().toISOString().split('T')[0]}`, headers, rows);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="credentials-dialog-title"
    >
      <div className="w-full max-w-2xl bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] shadow-lg p-6 max-h-[85vh] flex flex-col animate-in fade-in zoom-in-95 duration-100">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-[4px] bg-[#EAF5EF] text-[#1E7B4F]">
              <CheckCircle2 className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <h3 id="credentials-dialog-title" className="text-lg font-semibold text-[#1B2430]">
                Student Credentials Generated
              </h3>
              <p className="text-xs text-[#5B6675]">
                {successfulCreds.length} account{successfulCreds.length === 1 ? '' : 's'} provisioned successfully
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#5B6675] hover:text-[#1B2430] p-1 rounded transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning banner */}
        <div className="p-3 mb-4 rounded-[6px] bg-[#FDF6EC] border border-[#F6E1C4] flex items-start gap-3 text-xs text-[#A15C00]">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <strong className="font-semibold">Security Warning:</strong> These temporary passwords are shown only once and cannot be retrieved later. Download this CSV now and distribute credentials securely. Students will be required to change their password on first sign-in.
          </div>
        </div>

        {/* Credentials table */}
        <div className="flex-1 overflow-auto border border-[#E2E5EA] rounded-[4px] mb-5">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#F7F8FA] border-b border-[#E2E5EA] sticky top-0">
              <tr>
                <th className="p-2.5 font-semibold text-[#1B2430]">Roll No</th>
                <th className="p-2.5 font-semibold text-[#1B2430]">Full Name</th>
                <th className="p-2.5 font-semibold text-[#1B2430]">Email</th>
                <th className="p-2.5 font-semibold text-[#1B2430]">Temporary Password</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E2E5EA]">
              {credentials.map((cred, idx) => (
                <tr key={idx} className={cred.status === 'failed' ? 'bg-[#FDF0EF]' : 'hover:bg-[#F7F8FA]'}>
                  <td className="p-2.5 font-medium tabular-nums text-[#1B2430]">{cred.roll_number}</td>
                  <td className="p-2.5 text-[#1B2430]">{cred.full_name}</td>
                  <td className="p-2.5 text-[#5B6675]">{cred.email}</td>
                  <td className="p-2.5 font-mono text-[#1F3A5F]">
                    {cred.temp_password ? (
                      <span className="bg-[#EDF3FA] px-1.5 py-0.5 rounded border border-[#D0DFEF]">
                        {cred.temp_password}
                      </span>
                    ) : (
                      <span className="text-[#B3261E]">{cred.error || 'Failed'}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center gap-3 pt-2 border-t border-[#E2E5EA]">
          <button
            type="button"
            onClick={handleDownload}
            disabled={successfulCreds.length === 0}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] transition-colors disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>Download Credentials CSV</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium rounded-[6px] border border-[#E2E5EA] text-[#1B2430] hover:bg-[#F7F8FA] transition-colors"
          >
            I Have Saved These Credentials
          </button>
        </div>
      </div>
    </div>
  );
};
