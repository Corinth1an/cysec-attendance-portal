// src/components/common/EmptyState.tsx
import React from 'react';
import { Inbox } from 'lucide-react';

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  actionText?: string;
  onAction?: () => void;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon = <Inbox className="w-8 h-8 text-[#5B6675]" />,
  title,
  description,
  actionText,
  onAction,
  className = '',
}) => {
  return (
    <div
      className={`flex flex-col items-center justify-center p-8 text-center bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] ${className}`}
    >
      <div className="w-12 h-12 rounded-[6px] bg-[#F1F3F5] flex items-center justify-center mb-3">
        {icon}
      </div>
      <h3 className="text-base font-semibold text-[#1B2430] mb-1">{title}</h3>
      <p className="text-sm text-[#5B6675] max-w-sm mb-4 leading-normal">{description}</p>
      {actionText && onAction && (
        <button
          onClick={onAction}
          className="inline-flex items-center justify-center px-4 py-2 text-sm font-medium rounded-[6px] bg-[#1F3A5F] text-white hover:bg-[#162a45] transition-colors focus:ring-2 focus:ring-[#1F3A5F]"
        >
          {actionText}
        </button>
      )}
    </div>
  );
};
