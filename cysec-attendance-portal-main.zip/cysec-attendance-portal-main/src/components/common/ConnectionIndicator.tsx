// src/components/common/ConnectionIndicator.tsx
import React, { useEffect, useState } from 'react';
import { Wifi, WifiOff, RefreshCw } from 'lucide-react';
import { ConnectionState } from '../../types/database';

interface ConnectionIndicatorProps {
  state?: ConnectionState;
}

export const ConnectionIndicator: React.FC<ConnectionIndicatorProps> = ({ state: forcedState }) => {
  const [online, setOnline] = useState(navigator.onLine);
  const [isReconnecting, setIsReconnecting] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsReconnecting(true);
      setTimeout(() => {
        setOnline(true);
        setIsReconnecting(false);
      }, 1200);
    };

    const handleOffline = () => {
      setOnline(false);
      setIsReconnecting(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const currentState: ConnectionState = forcedState
    ? forcedState
    : !online
    ? 'OFFLINE'
    : isReconnecting
    ? 'RECONNECTING'
    : 'LIVE';

  if (currentState === 'LIVE') {
    return (
      <div
        className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-[#EAF5EF] text-[#1E7B4F] border border-[#C6E6D4]"
        title="Realtime connection active"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-[#1E7B4F]" />
        <span>Live</span>
      </div>
    );
  }

  if (currentState === 'RECONNECTING') {
    return (
      <div
        className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-[#FDF6EC] text-[#A15C00] border border-[#F6E1C4]"
        title="Re-establishing connection..."
      >
        <RefreshCw className="w-3 h-3 animate-spin text-[#A15C00]" />
        <span>Reconnecting</span>
      </div>
    );
  }

  return (
    <div
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-[#FDF0EF] text-[#B3261E] border border-[#F8CBC8]"
      title="You are offline. Mark Attendance is disabled."
    >
      <WifiOff className="w-3 h-3 text-[#B3261E]" />
      <span>Offline</span>
    </div>
  );
};
