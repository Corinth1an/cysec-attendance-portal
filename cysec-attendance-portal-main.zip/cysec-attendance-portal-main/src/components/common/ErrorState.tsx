// src/components/common/ErrorState.tsx
import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface ErrorStateProps {
  title?: string;
  message?: string;
  onRetry?: () => void;
  className?: string;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  title = 'Failed to load content',
  message = 'An unexpected error occurred while communicating with the database.',
  onRetry,
  className = '',
}) => {
  return (
    <div
      role="alert"
      className={`flex flex-col items-center justify-center p-8 text-center bg-[#FFFFFF] border border-[#E2E5EA] rounded-[6px] ${className}`}
    >
      <div className="w-12 h-12 rounded-[6px] bg-[#FDF0EF] flex items-center justify-center mb-3">
        <AlertCircle className="w-6 h-6 text-[#B3261E]" />
      </div>
      <h3 className="text-base font-semibold text-[#1B2430] mb-1">{title}</h3>
      <p className="text-sm text-[#5B6675] max-w-sm mb-4 leading-normal">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-2 justify-center px-4 py-2 text-sm font-medium rounded-[6px] border border-[#E2E5EA] bg-[#FFFFFF] text-[#1B2430] hover:bg-[#F7F8FA] transition-colors focus:ring-2 focus:ring-[#1F3A5F]"
        >
          <RefreshCw className="w-4 h-4 text-[#5B6675]" />
          <span>Retry</span>
        </button>
      )}
    </div>
  );
};
