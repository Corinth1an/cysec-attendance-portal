// src/App.tsx
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { ErrorBoundary } from './components/common/ErrorBoundary';

import { AppLayout } from './components/layout/AppLayout';
import { RequireAuth } from './components/layout/RequireAuth';
import { RequireRole } from './components/layout/RequireRole';

import { Login } from './pages/auth/Login';
import { ChangePassword } from './pages/auth/ChangePassword';

import { TeacherDashboard } from './pages/teacher/TeacherDashboard';
import { TeacherClasses } from './pages/teacher/TeacherClasses';
import { TeacherStudents } from './pages/teacher/TeacherStudents';
import { TeacherCourses } from './pages/teacher/TeacherCourses';
import { TeacherLive } from './pages/teacher/TeacherLive';
import { TeacherHistory } from './pages/teacher/TeacherHistory';
import { TeacherReports } from './pages/teacher/TeacherReports';
import { TeacherSettings } from './pages/teacher/TeacherSettings';

import { StudentDashboard } from './pages/student/StudentDashboard';
import { StudentAttendance } from './pages/student/StudentAttendance';
import { StudentCourses } from './pages/student/StudentCourses';
import { StudentProfile } from './pages/student/StudentProfile';

import { NotFound } from './pages/NotFound';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: true,
      retry: 1,
    },
  },
});

const RootRedirect: React.FC = () => {
  const { user, profile, isLoading } = useAuth();
  if (isLoading) return null;
  if (!user || !profile) return <Navigate to="/login" replace />;
  if (profile.must_change_password) return <Navigate to="/change-password" replace />;
  return <Navigate to={profile.role === 'teacher' ? '/t' : '/s'} replace />;
};

export default function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <ToastProvider>
            <BrowserRouter>
              <Routes>
                {/* Root Redirect */}
                <Route path="/" element={<RootRedirect />} />

                {/* Public Auth */}
                <Route path="/login" element={<Login />} />

                {/* Forced Change Password */}
                <Route
                  path="/change-password"
                  element={
                    <RequireAuth>
                      <ChangePassword />
                    </RequireAuth>
                  }
                />

                {/* Teacher Portal */}
                <Route
                  path="/t"
                  element={
                    <RequireAuth>
                      <RequireRole role="teacher">
                        <AppLayout />
                      </RequireRole>
                    </RequireAuth>
                  }
                >
                  <Route index element={<TeacherDashboard />} />
                  <Route path="classes" element={<TeacherClasses />} />
                  <Route path="students" element={<TeacherStudents />} />
                  <Route path="courses" element={<TeacherCourses />} />
                  <Route path="live" element={<TeacherLive />} />
                  <Route path="history" element={<TeacherHistory />} />
                  <Route path="reports" element={<TeacherReports />} />
                  <Route path="settings" element={<TeacherSettings />} />
                </Route>

                {/* Student Portal */}
                <Route
                  path="/s"
                  element={
                    <RequireAuth>
                      <RequireRole role="student">
                        <AppLayout />
                      </RequireRole>
                    </RequireAuth>
                  }
                >
                  <Route index element={<StudentDashboard />} />
                  <Route path="attendance" element={<StudentAttendance />} />
                  <Route path="courses" element={<StudentCourses />} />
                  <Route path="profile" element={<StudentProfile />} />
                </Route>

                {/* 404 Catch-All */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </ToastProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}
