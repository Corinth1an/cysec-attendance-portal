// src/lib/csv.ts
// Secure CSV generation with formula injection neutralization and CSV parsing

/**
 * Escapes quotes and neutralizes CSV Formula Injection (DDE injection).
 * Any cell starting with =, +, -, @, tab (\t), or CR (\r) is prepended with a single quote (').
 */
export function sanitizeCSVCell(value: any): string {
  if (value === null || value === undefined) {
    return '""';
  }
  let str = String(value);

  // Formula injection neutralization
  const formulaTriggers = ['=', '+', '-', '@', '\t', '\r'];
  if (formulaTriggers.some((trigger) => str.startsWith(trigger))) {
    str = `'${str}`;
  }

  // Escape inner double quotes by doubling them
  const escaped = str.replace(/"/g, '""');
  return `"${escaped}"`;
}

/**
 * Generates and triggers download of a sanitized CSV file.
 */
export function exportToCSV(filename: string, headers: string[], rows: (string | number | boolean | null | undefined)[][]): void {
  const headerLine = headers.map(sanitizeCSVCell).join(',');
  const rowLines = rows.map((row) => row.map(sanitizeCSVCell).join(','));
  const csvContent = [headerLine, ...rowLines].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename.endsWith('.csv') ? filename : `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export interface ParsedStudentRow {
  rowNumber: number;
  full_name: string;
  roll_number: string;
  email: string;
  errors: string[];
}

/**
 * Parses and validates CSV string for student import.
 * Rules:
 * - Columns: full_name, roll_number, email
 * - Max 100 rows
 * - Email regex & lowercase
 * - Roll number format ^[A-Za-z0-9-]{1,20}$
 * - Full name 1-100 characters
 */
export function parseStudentsCSV(csvText: string): {
  success: boolean;
  rows: ParsedStudentRow[];
  globalErrors: string[];
} {
  const globalErrors: string[] = [];
  const lines = csvText.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);

  if (lines.length === 0) {
    return { success: false, rows: [], globalErrors: ['The CSV file is empty.'] };
  }

  const headerLine = lines[0].toLowerCase();
  const headers = headerLine.split(',').map((h) => h.replace(/["']/g, '').trim());

  const nameIdx = headers.indexOf('full_name');
  const rollIdx = headers.indexOf('roll_number');
  const emailIdx = headers.indexOf('email');

  if (nameIdx === -1 || rollIdx === -1 || emailIdx === -1) {
    return {
      success: false,
      rows: [],
      globalErrors: [
        'Missing required headers. CSV must have columns: full_name, roll_number, email',
      ],
    };
  }

  const dataLines = lines.slice(1);
  if (dataLines.length === 0) {
    return { success: false, rows: [], globalErrors: ['No data rows found in CSV.'] };
  }

  if (dataLines.length > 100) {
    return {
      success: false,
      rows: [],
      globalErrors: [`Maximum 100 students can be imported in one batch (found ${dataLines.length}).`],
    };
  }

  const parsedRows: ParsedStudentRow[] = [];
  const seenRolls = new Set<string>();
  const seenEmails = new Set<string>();

  dataLines.forEach((line, index) => {
    const rowNum = index + 2; // header is row 1
    // Basic comma splitter respecting quotes
    const cells = line.split(',').map((c) => c.replace(/^["']|["']$/g, '').trim());
    const fullName = cells[nameIdx] || '';
    const rollNumber = cells[rollIdx] || '';
    const email = (cells[emailIdx] || '').toLowerCase();

    const rowErrors: string[] = [];

    if (!fullName || fullName.length < 1 || fullName.length > 100) {
      rowErrors.push('Full name must be between 1 and 100 characters');
    }

    const rollRegex = /^[A-Za-z0-9-]{1,20}$/;
    if (!rollRegex.test(rollNumber)) {
      rowErrors.push('Roll number must be alphanumeric (1-20 characters, hyphen allowed)');
    } else if (seenRolls.has(rollNumber)) {
      rowErrors.push(`Duplicate roll number in file: ${rollNumber}`);
    } else {
      seenRolls.add(rollNumber);
    }

    const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
    if (!emailRegex.test(email)) {
      rowErrors.push('Invalid email address format');
    } else if (seenEmails.has(email)) {
      rowErrors.push(`Duplicate email in file: ${email}`);
    } else {
      seenEmails.add(email);
    }

    parsedRows.push({
      rowNumber: rowNum,
      full_name: fullName,
      roll_number: rollNumber,
      email,
      errors: rowErrors,
    });
  });

  const hasAnyErrors = parsedRows.some((r) => r.errors.length > 0);

  return {
    success: !hasAnyErrors && globalErrors.length === 0,
    rows: parsedRows,
    globalErrors,
  };
}
