// src/lib/supabase.ts
// Supabase client instance, connection monitoring, and server clock offset management

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  !supabaseUrl.includes('your-project-ref') &&
  supabaseUrl.startsWith('https://')
);

// Fallback dummy URL so createClient doesn't throw during initial render if unconfigured
export const supabase = createClient(
  isSupabaseConfigured ? supabaseUrl : 'https://placeholder-domain-999.supabase.co',
  isSupabaseConfigured ? supabaseAnonKey : 'placeholder-anon-key-999',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: false,
    },
    realtime: {
      params: {
        eventsPerSecond: 10,
      },
    },
  }
);

let serverClockSkewMs = 0;

/**
 * Synchronizes client clock with the database server using server_now() RPC.
 * Returns the offset in milliseconds.
 */
export async function syncServerClock(): Promise<number> {
  if (!isSupabaseConfigured) return 0;
  try {
    const start = Date.now();
    const { data, error } = await supabase.rpc('server_now');
    const end = Date.now();
    if (error || !data) return serverClockSkewMs;

    const latency = (end - start) / 2;
    const serverTime = new Date(data).getTime() + latency;
    serverClockSkewMs = serverTime - end;
    return serverClockSkewMs;
  } catch (_e) {
    return serverClockSkewMs;
  }
}

/**
 * Returns current server time estimated using the synchronized clock skew.
 */
export function getServerTime(): Date {
  return new Date(Date.now() + serverClockSkewMs);
}
