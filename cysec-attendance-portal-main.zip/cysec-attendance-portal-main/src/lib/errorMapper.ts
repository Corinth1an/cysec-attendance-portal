// src/lib/errorMapper.ts
// Maps RPC and PostgREST errors into clean, friendly user-facing messages.
// Never exposes database column names, SQL queries, or stack traces.

export function mapErrorMessage(error: any): string {
  if (!error) return 'An unexpected error occurred.';

  const rawMessage = typeof error === 'string' ? error : (error.message || '');
  const code = error.code || '';

  if (rawMessage.includes('ALREADY_MARKED') || code === 'ALREADY_MARKED') {
    return "You've already marked attendance for this session.";
  }
  if (rawMessage.includes('SESSION_CLOSED') || code === 'SESSION_CLOSED') {
    return 'This attendance session has already closed.';
  }
  if (rawMessage.includes('SESSION_EXPIRED') || code === 'SESSION_EXPIRED') {
    return 'This attendance session has expired and can no longer be marked.';
  }
  if (rawMessage.includes('SESSION_ALREADY_OPEN') || code === 'SESSION_ALREADY_OPEN') {
    return 'An attendance session is already active for this class.';
  }
  if (rawMessage.includes('CLASS_LIMIT') || code === 'CLASS_LIMIT') {
    return 'Maximum class limit reached. You can manage at most 2 classes.';
  }
  if (rawMessage.includes('NOT_ALLOWED') || code === 'NOT_ALLOWED' || code === '42501') {
    return 'You are not authorized to perform this action.';
  }
  if (rawMessage.includes('INVALID_INPUT') || code === 'INVALID_INPUT') {
    return 'The provided information is invalid. Please check your inputs.';
  }
  if (rawMessage.includes('unique constraint') || code === '23505') {
    if (rawMessage.includes('roll_number')) {
      return 'A student with this roll number already exists in this class.';
    }
    if (rawMessage.includes('code') || rawMessage.includes('course_code')) {
      return 'An entry with this code already exists.';
    }
    return 'A conflicting record already exists with these unique details.';
  }
  if (code === 'PGRST116') {
    return 'The requested record could not be found.';
  }
  if (error.status === 401 || rawMessage.toLowerCase().includes('jwt')) {
    return 'Your session has expired. Please sign in again.';
  }

  // Generic fallback for any other database or network exception
  return 'Something went wrong. Please try again.';
}
