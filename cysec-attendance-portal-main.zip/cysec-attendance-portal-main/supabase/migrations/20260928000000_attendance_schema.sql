-- Migration: 20260928000000_attendance_schema.sql
-- Production Attendance Schema with Least Privilege RLS, Strict Constraints, and Realtime

create extension if not exists pgcrypto;

-- 1. ENUMS
create type public.app_role as enum ('teacher', 'student');
create type public.session_status as enum ('OPEN', 'CLOSED', 'CANCELLED');
create type public.attendance_status as enum ('PRESENT', 'LATE', 'ABSENT');
create type public.attendance_source as enum ('SELF', 'TEACHER', 'SYSTEM');

-- 2. TABLES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.app_role not null,
  full_name text not null check (char_length(full_name) between 1 and 100),
  must_change_password boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.classes (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id),
  name text not null check (char_length(name) between 1 and 80),
  code text not null check (code ~ '^[A-Za-z0-9-]{1,20}$'),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (teacher_id, code)
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references public.profiles(id),
  class_id uuid not null references public.classes(id),
  roll_number text not null check (roll_number ~ '^[A-Za-z0-9-]{1,20}$'),
  full_name text not null check (char_length(full_name) between 1 and 100),
  email text not null check (email = lower(email) and email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (class_id, roll_number),
  unique (id, class_id)
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id),
  course_code text not null check (course_code ~ '^[A-Za-z0-9-]{1,20}$'),
  course_name text not null check (char_length(course_name) between 1 and 100),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (class_id, course_code),
  unique (id, class_id)
);

create table public.attendance_sessions (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id),
  course_id uuid not null,
  session_date date not null default current_date,
  status public.session_status not null default 'OPEN',
  opened_at timestamptz not null default now(),
  late_after timestamptz not null,
  expires_at timestamptz not null,
  closed_at timestamptz,
  created_by uuid not null references public.profiles(id),
  foreign key (course_id, class_id) references public.courses (id, class_id),
  check (expires_at > opened_at),
  check (late_after >= opened_at and late_after <= expires_at),
  check ((status = 'OPEN' and closed_at is null) or (status in ('CLOSED', 'CANCELLED') and closed_at is not null) or (status = 'CANCELLED' and closed_at is null))
);

create unique index one_open_session_per_class on public.attendance_sessions (class_id) where status = 'OPEN';
create index attendance_sessions_class_opened_idx on public.attendance_sessions (class_id, opened_at desc);

create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.attendance_sessions(id),
  student_id uuid not null references public.students(id),
  status public.attendance_status not null,
  marked_at timestamptz not null default now(),
  marked_by uuid references public.profiles(id),
  source public.attendance_source not null,
  unique (session_id, student_id)
);

create index attendance_student_id_idx on public.attendance (student_id);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

-- 3. TRIGGERS

-- Trigger: Enforce max 2 classes per teacher
create or replace function public.check_class_limit()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_count integer;
begin
  select count(*) into v_count
  from public.classes
  where teacher_id = NEW.teacher_id;

  if v_count >= 2 then
    raise exception 'CLASS_LIMIT: A teacher can create at most 2 classes' using errcode = 'P0001';
  end if;
  return NEW;
end;
$$;

create trigger tr_check_class_limit
before insert on public.classes
for each row execute function public.check_class_limit();

-- Trigger: Block updates to students immutable fields (profile_id, class_id, email)
create or replace function public.block_student_immutable_fields()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if NEW.profile_id <> OLD.profile_id or NEW.class_id <> OLD.class_id or NEW.email <> OLD.email then
    raise exception 'INVALID_INPUT: Cannot modify profile_id, class_id, or email of student' using errcode = 'P0001';
  end if;
  return NEW;
end;
$$;

create trigger tr_block_student_immutable_fields
before update on public.students
for each row execute function public.block_student_immutable_fields();

-- Trigger: Verify student class matches attendance session class
create or replace function public.verify_attendance_student_class()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_student_class_id uuid;
  v_session_class_id uuid;
begin
  select class_id into v_student_class_id from public.students where id = NEW.student_id;
  select class_id into v_session_class_id from public.attendance_sessions where id = NEW.session_id;

  if v_student_class_id is null or v_session_class_id is null or v_student_class_id <> v_session_class_id then
    raise exception 'NOT_ALLOWED: Student does not belong to the session class' using errcode = 'P0001';
  end if;
  return NEW;
end;
$$;

create trigger tr_verify_attendance_student_class
before insert or update on public.attendance
for each row execute function public.verify_attendance_student_class();

-- Updated_at timestamp trigger
create or replace function public.handle_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  NEW.updated_at = now();
  return NEW;
end;
$$;

create trigger set_profiles_updated_at before update on public.profiles for each row execute function public.handle_updated_at();
create trigger set_classes_updated_at before update on public.classes for each row execute function public.handle_updated_at();
create trigger set_students_updated_at before update on public.students for each row execute function public.handle_updated_at();
create trigger set_courses_updated_at before update on public.courses for each row execute function public.handle_updated_at();

-- Generic audit_row_change() SECURITY DEFINER trigger
create or replace function public.audit_row_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_actor_id uuid;
  v_meta jsonb := '{}'::jsonb;
begin
  begin
    v_actor_id := auth.uid();
  exception when others then
    v_actor_id := null;
  end;

  if TG_OP = 'INSERT' then
    if TG_TABLE_NAME = 'classes' then
      v_meta := jsonb_build_object('name', NEW.name, 'code', NEW.code, 'is_active', NEW.is_active);
    elsif TG_TABLE_NAME = 'students' then
      v_meta := jsonb_build_object('roll_number', NEW.roll_number, 'full_name', NEW.full_name, 'is_active', NEW.is_active, 'class_id', NEW.class_id);
    elsif TG_TABLE_NAME = 'courses' then
      v_meta := jsonb_build_object('course_code', NEW.course_code, 'course_name', NEW.course_name, 'is_active', NEW.is_active, 'class_id', NEW.class_id);
    end if;

    insert into public.audit_logs (actor_id, action, entity_type, entity_id, metadata, created_at)
    values (v_actor_id, TG_TABLE_NAME || '_created', TG_TABLE_NAME, NEW.id, v_meta, now());
    return NEW;

  elsif TG_OP = 'UPDATE' then
    if TG_TABLE_NAME = 'classes' then
      v_meta := jsonb_build_object('old', jsonb_build_object('name', OLD.name, 'code', OLD.code, 'is_active', OLD.is_active),
                                   'new', jsonb_build_object('name', NEW.name, 'code', NEW.code, 'is_active', NEW.is_active));
    elsif TG_TABLE_NAME = 'students' then
      v_meta := jsonb_build_object('old', jsonb_build_object('roll_number', OLD.roll_number, 'full_name', OLD.full_name, 'is_active', OLD.is_active),
                                   'new', jsonb_build_object('roll_number', NEW.roll_number, 'full_name', NEW.full_name, 'is_active', NEW.is_active));
    elsif TG_TABLE_NAME = 'courses' then
      v_meta := jsonb_build_object('old', jsonb_build_object('course_code', OLD.course_code, 'course_name', OLD.course_name, 'is_active', OLD.is_active),
                                   'new', jsonb_build_object('course_code', NEW.course_code, 'course_name', NEW.course_name, 'is_active', NEW.is_active));
    end if;

    insert into public.audit_logs (actor_id, action, entity_type, entity_id, metadata, created_at)
    values (v_actor_id, TG_TABLE_NAME || '_updated', TG_TABLE_NAME, NEW.id, v_meta, now());
    return NEW;
  end if;

  return null;
end;
$$;

create trigger tr_audit_classes after insert or update on public.classes for each row execute function public.audit_row_change();
create trigger tr_audit_students after insert or update on public.students for each row execute function public.audit_row_change();
create trigger tr_audit_courses after insert or update on public.courses for each row execute function public.audit_row_change();

-- 4. REALTIME PUBLICATION
alter publication supabase_realtime add table public.attendance_sessions, public.attendance;

-- 5. VIEW (Security Invoker)
create view public.v_student_course_stats with (security_invoker = true) as
select
  a.student_id,
  s.class_id,
  s.course_id,
  count(*) filter (where a.status = 'PRESENT') as present_count,
  count(*) filter (where a.status = 'LATE')    as late_count,
  count(*) filter (where a.status = 'ABSENT')  as absent_count,
  count(*) as total_sessions,
  round(100.0 * count(*) filter (where a.status in ('PRESENT','LATE')) / nullif(count(*), 0), 1) as attendance_pct
from public.attendance a
join public.attendance_sessions s on s.id = a.session_id
where s.status = 'CLOSED'
group by a.student_id, s.class_id, s.course_id;

-- 6. SECURITY DEFINER HELPER FUNCTIONS
create or replace function public.is_teacher()
returns boolean
language sql
security definer
stable
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'teacher'
  );
$$;

create or replace function public.teacher_owns_class(p_class_id uuid)
returns boolean
language sql
security definer
stable
set search_path = ''
as $$
  select exists (
    select 1 from public.classes
    where id = p_class_id
      and teacher_id = (select auth.uid())
      and (select public.is_teacher())
  );
$$;

create or replace function public.my_student_id()
returns uuid
language sql
security definer
stable
set search_path = ''
as $$
  select id from public.students
  where profile_id = (select auth.uid())
    and is_active = true
  limit 1;
$$;

create or replace function public.my_class_id()
returns uuid
language sql
security definer
stable
set search_path = ''
as $$
  select class_id from public.students
  where profile_id = (select auth.uid())
    and is_active = true
  limit 1;
$$;

-- 7. ROW LEVEL SECURITY (RLS) & GRANTS

-- Enable and force RLS on every table
alter table public.profiles enable row level security;
alter table public.profiles force row level security;

alter table public.classes enable row level security;
alter table public.classes force row level security;

alter table public.students enable row level security;
alter table public.students force row level security;

alter table public.courses enable row level security;
alter table public.courses force row level security;

alter table public.attendance_sessions enable row level security;
alter table public.attendance_sessions force row level security;

alter table public.attendance enable row level security;
alter table public.attendance force row level security;

alter table public.audit_logs enable row level security;
alter table public.audit_logs force row level security;

-- Revoke all by default
revoke all on all tables in schema public from anon, public;
revoke all on all sequences in schema public from anon, public;
revoke all on all functions in schema public from anon, public;

-- Grant specific permissions to authenticated
grant select on public.profiles to authenticated;

grant select, insert on public.classes to authenticated;
grant update(name, code, is_active) on public.classes to authenticated;

grant select on public.students to authenticated;
grant update(roll_number, full_name, is_active) on public.students to authenticated;

grant select, insert on public.courses to authenticated;
grant update(course_code, course_name, is_active) on public.courses to authenticated;

grant select on public.attendance_sessions to authenticated;
grant select on public.attendance to authenticated;
grant select on public.audit_logs to authenticated;
grant select on public.v_student_course_stats to authenticated;

-- Policies

-- profiles
create policy "profiles_select_own"
on public.profiles
for select
to authenticated
using (id = (select auth.uid()));

-- classes
create policy "classes_teacher_select"
on public.classes
for select
to authenticated
using (teacher_id = (select auth.uid()) and (select public.is_teacher()));

create policy "classes_teacher_insert"
on public.classes
for insert
to authenticated
with check (teacher_id = (select auth.uid()) and (select public.is_teacher()));

create policy "classes_teacher_update"
on public.classes
for update
to authenticated
using (teacher_id = (select auth.uid()) and (select public.is_teacher()))
with check (teacher_id = (select auth.uid()) and (select public.is_teacher()));

create policy "classes_student_select"
on public.classes
for select
to authenticated
using (id = (select public.my_class_id()));

-- students
create policy "students_teacher_select"
on public.students
for select
to authenticated
using (public.teacher_owns_class(class_id));

create policy "students_teacher_update"
on public.students
for update
to authenticated
using (public.teacher_owns_class(class_id))
with check (public.teacher_owns_class(class_id));

create policy "students_own_select"
on public.students
for select
to authenticated
using (profile_id = (select auth.uid()));

-- courses
create policy "courses_teacher_select"
on public.courses
for select
to authenticated
using (public.teacher_owns_class(class_id));

create policy "courses_teacher_insert"
on public.courses
for insert
to authenticated
with check (public.teacher_owns_class(class_id));

create policy "courses_teacher_update"
on public.courses
for update
to authenticated
using (public.teacher_owns_class(class_id))
with check (public.teacher_owns_class(class_id));

create policy "courses_student_select"
on public.courses
for select
to authenticated
using (class_id = (select public.my_class_id()) and is_active = true);

-- attendance_sessions
create policy "attendance_sessions_teacher_select"
on public.attendance_sessions
for select
to authenticated
using (public.teacher_owns_class(class_id));

create policy "attendance_sessions_student_select"
on public.attendance_sessions
for select
to authenticated
using (class_id = (select public.my_class_id()));

-- attendance
create policy "attendance_teacher_select"
on public.attendance
for select
to authenticated
using (
  exists (
    select 1 from public.attendance_sessions s
    where s.id = attendance.session_id
      and public.teacher_owns_class(s.class_id)
  )
);

create policy "attendance_student_select"
on public.attendance
for select
to authenticated
using (student_id = (select public.my_student_id()));

-- audit_logs
create policy "audit_logs_teacher_select"
on public.audit_logs
for select
to authenticated
using (actor_id = (select auth.uid()));


-- 8. RPCS & INTERNAL FUNCTIONS

-- Internal helper: _finalize_session (Not granted to public or authenticated)
create or replace function public._finalize_session(p_session_id uuid, p_actor_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session record;
  v_inserted_absent int := 0;
begin
  select * into v_session
  from public.attendance_sessions
  where id = p_session_id
  for update;

  if not found then
    raise exception 'INVALID_INPUT: Session not found' using errcode = 'P0001';
  end if;

  if v_session.status <> 'OPEN' then
    return;
  end if;

  -- Close session
  update public.attendance_sessions
  set status = 'CLOSED', closed_at = now()
  where id = p_session_id;

  -- Insert ABSENT rows for all active students in class who have not marked
  with inserted as (
    insert into public.attendance (session_id, student_id, status, marked_at, marked_by, source)
    select p_session_id, st.id, 'ABSENT', now(), null, 'SYSTEM'
    from public.students st
    where st.class_id = v_session.class_id
      and st.is_active = true
      and not exists (
        select 1 from public.attendance a
        where a.session_id = p_session_id
          and a.student_id = st.id
      )
    on conflict (session_id, student_id) do nothing
    returning id
  )
  select count(*) into v_inserted_absent from inserted;

  -- Write audit log
  insert into public.audit_logs (actor_id, action, entity_type, entity_id, metadata, created_at)
  values (
    p_actor_id,
    'session_closed',
    'attendance_sessions',
    p_session_id,
    jsonb_build_object('auto_absent_count', v_inserted_absent),
    now()
  );
end;
$$;

-- RPC: open_session
create or replace function public.open_session(
  p_class_id uuid,
  p_course_id uuid,
  p_duration_minutes int default 10,
  p_late_after_minutes int default 5
)
returns public.attendance_sessions
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid;
  v_class record;
  v_course record;
  v_opened_at timestamptz := now();
  v_late_after timestamptz;
  v_expires_at timestamptz;
  v_new_session public.attendance_sessions;
begin
  v_uid := auth.uid();
  if v_uid is null then
    raise exception 'NOT_ALLOWED: Authentication required' using errcode = 'P0001';
  end if;

  -- Check teacher owns active class
  select * into v_class
  from public.classes
  where id = p_class_id and teacher_id = v_uid and is_active = true;

  if not found then
    raise exception 'NOT_ALLOWED: Class not found or not owned by teacher' using errcode = 'P0001';
  end if;

  -- Check active course belongs to class
  select * into v_course
  from public.courses
  where id = p_course_id and class_id = p_class_id and is_active = true;

  if not found then
    raise exception 'INVALID_INPUT: Course does not belong to active class or is inactive' using errcode = 'P0001';
  end if;

  -- Validation
  if p_duration_minutes < 1 or p_duration_minutes > 120 then
    raise exception 'INVALID_INPUT: Duration must be between 1 and 120 minutes' using errcode = 'P0001';
  end if;

  if p_late_after_minutes < 0 or p_late_after_minutes > p_duration_minutes then
    raise exception 'INVALID_INPUT: Late threshold must be <= duration minutes' using errcode = 'P0001';
  end if;

  v_late_after := v_opened_at + (p_late_after_minutes || ' minutes')::interval;
  v_expires_at := v_opened_at + (p_duration_minutes || ' minutes')::interval;

  -- Unique index one_open_session_per_class handles race conditions, but we can check early
  if exists (select 1 from public.attendance_sessions where class_id = p_class_id and status = 'OPEN') then
    raise exception 'SESSION_ALREADY_OPEN: A session is already open for this class' using errcode = 'P0001';
  end if;

  begin
    insert into public.attendance_sessions (
      class_id, course_id, session_date, status, opened_at, late_after, expires_at, closed_at, created_by
    )
    values (
      p_class_id, p_course_id, current_date, 'OPEN', v_opened_at, v_late_after, v_expires_at, null, v_uid
    )
    returning * into v_new_session;
  exception when unique_violation then
    raise exception 'SESSION_ALREADY_OPEN: A session is already open for this class' using errcode = 'P0001';
  end;

  -- Audit log
  insert into public.audit_logs (actor_id, action, entity_type, entity_id, metadata, created_at)
  values (
    v_uid,
    'session_opened',
    'attendance_sessions',
    v_new_session.id,
    jsonb_build_object(
      'class_id', p_class_id,
      'course_id', p_course_id,
      'duration_minutes', p_duration_minutes,
      'late_after_minutes', p_late_after_minutes
    ),
    now()
  );

  return v_new_session;
end;
$$;

-- RPC: mark_my_attendance
create or replace function public.mark_my_attendance(p_session_id uuid)
returns public.attendance
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid;
  v_student record;
  v_session record;
  v_now timestamptz := now();
  v_status public.attendance_status;
  v_result public.attendance;
begin
  v_uid := auth.uid();
  if v_uid is null then
    raise exception 'NOT_ALLOWED: Authentication required' using errcode = 'P0001';
  end if;

  -- Resolve active student
  select * into v_student
  from public.students
  where profile_id = v_uid and is_active = true;

  if not found then
    raise exception 'NOT_ALLOWED: Active student profile not found' using errcode = 'P0001';
  end if;

  -- Check session
  select * into v_session
  from public.attendance_sessions
  where id = p_session_id;

  if not found then
    raise exception 'INVALID_INPUT: Session not found' using errcode = 'P0001';
  end if;

  if v_session.class_id <> v_student.class_id then
    raise exception 'NOT_ALLOWED: Student not enrolled in session class' using errcode = 'P0001';
  end if;

  if v_session.status <> 'OPEN' then
    raise exception 'SESSION_CLOSED: Session is closed' using errcode = 'P0001';
  end if;

  if v_now >= v_session.expires_at then
    raise exception 'SESSION_EXPIRED: Session has expired' using errcode = 'P0001';
  end if;

  if v_now > v_session.late_after then
    v_status := 'LATE';
  else
    v_status := 'PRESENT';
  end if;

  -- Insert with ON CONFLICT DO NOTHING
  insert into public.attendance (
    session_id, student_id, status, marked_at, marked_by, source
  )
  values (
    p_session_id, v_student.id, v_status, v_now, v_uid, 'SELF'
  )
  on conflict (session_id, student_id) do nothing
  returning * into v_result;

  if v_result.id is null then
    raise exception 'ALREADY_MARKED: Attendance already marked for this session' using errcode = 'P0001';
  end if;

  return v_result;
end;
$$;

-- RPC: close_session
create or replace function public.close_session(p_session_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid;
  v_session record;
begin
  v_uid := auth.uid();
  if v_uid is null then
    raise exception 'NOT_ALLOWED: Authentication required' using errcode = 'P0001';
  end if;

  select * into v_session
  from public.attendance_sessions
  where id = p_session_id;

  if not found then
    raise exception 'INVALID_INPUT: Session not found' using errcode = 'P0001';
  end if;

  if not public.teacher_owns_class(v_session.class_id) then
    raise exception 'NOT_ALLOWED: Teacher does not own session class' using errcode = 'P0001';
  end if;

  perform public._finalize_session(p_session_id, v_uid);
end;
$$;

-- RPC: close_expired_sessions (Scheduled / Admin / internal)
create or replace function public.close_expired_sessions()
returns int
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_session record;
  v_count int := 0;
begin
  for v_session in
    select id, created_by
    from public.attendance_sessions
    where status = 'OPEN' and expires_at <= now()
  loop
    perform public._finalize_session(v_session.id, v_session.created_by);
    v_count := v_count + 1;
  end loop;
  return v_count;
end;
$$;

-- RPC: cancel_session
create or replace function public.cancel_session(p_session_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid;
  v_session record;
begin
  v_uid := auth.uid();
  if v_uid is null then
    raise exception 'NOT_ALLOWED: Authentication required' using errcode = 'P0001';
  end if;

  select * into v_session
  from public.attendance_sessions
  where id = p_session_id
  for update;

  if not found then
    raise exception 'INVALID_INPUT: Session not found' using errcode = 'P0001';
  end if;

  if not public.teacher_owns_class(v_session.class_id) then
    raise exception 'NOT_ALLOWED: Teacher does not own session class' using errcode = 'P0001';
  end if;

  if v_session.status <> 'OPEN' then
    raise exception 'INVALID_INPUT: Only OPEN sessions can be cancelled' using errcode = 'P0001';
  end if;

  update public.attendance_sessions
  set status = 'CANCELLED', closed_at = now()
  where id = p_session_id;

  insert into public.audit_logs (actor_id, action, entity_type, entity_id, metadata, created_at)
  values (v_uid, 'session_cancelled', 'attendance_sessions', p_session_id, '{}'::jsonb, now());
end;
$$;

-- RPC: set_attendance (Teacher manual correction)
create or replace function public.set_attendance(
  p_session_id uuid,
  p_student_id uuid,
  p_status public.attendance_status
)
returns public.attendance
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid;
  v_session record;
  v_student record;
  v_old_status text := null;
  v_res public.attendance;
begin
  v_uid := auth.uid();
  if v_uid is null then
    raise exception 'NOT_ALLOWED: Authentication required' using errcode = 'P0001';
  end if;

  select * into v_session
  from public.attendance_sessions
  where id = p_session_id;

  if not found then
    raise exception 'INVALID_INPUT: Session not found' using errcode = 'P0001';
  end if;

  if not public.teacher_owns_class(v_session.class_id) then
    raise exception 'NOT_ALLOWED: Teacher does not own session class' using errcode = 'P0001';
  end if;

  if v_session.status = 'CANCELLED' then
    raise exception 'NOT_ALLOWED: Cannot modify attendance for cancelled session' using errcode = 'P0001';
  end if;

  -- Check student is in the same class
  select * into v_student
  from public.students
  where id = p_student_id and class_id = v_session.class_id;

  if not found then
    raise exception 'INVALID_INPUT: Student not found in session class' using errcode = 'P0001';
  end if;

  -- Get old status if exists
  select status::text into v_old_status
  from public.attendance
  where session_id = p_session_id and student_id = p_student_id;

  -- Upsert
  insert into public.attendance (
    session_id, student_id, status, marked_at, marked_by, source
  )
  values (
    p_session_id, p_student_id, p_status, now(), v_uid, 'TEACHER'
  )
  on conflict (session_id, student_id) do update
  set status = EXCLUDED.status,
      marked_at = now(),
      marked_by = v_uid,
      source = 'TEACHER'
  returning * into v_res;

  -- Audit log with old and new status
  insert into public.audit_logs (actor_id, action, entity_type, entity_id, metadata, created_at)
  values (
    v_uid,
    'attendance_corrected',
    'attendance',
    v_res.id,
    jsonb_build_object(
      'session_id', p_session_id,
      'student_id', p_student_id,
      'old_status', v_old_status,
      'new_status', p_status::text
    ),
    now()
  );

  return v_res;
end;
$$;

-- RPC: clear_must_change_password
create or replace function public.clear_must_change_password()
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid;
begin
  v_uid := auth.uid();
  if v_uid is null then
    raise exception 'NOT_ALLOWED: Authentication required' using errcode = 'P0001';
  end if;

  update public.profiles
  set must_change_password = false
  where id = v_uid;
end;
$$;

-- RPC: server_now (For calculating clock skew / offset)
create or replace function public.server_now()
returns timestamptz
language sql
security definer
stable
set search_path = ''
as $$
  select now();
$$;

-- 9. EXECUTE GRANTS FOR RPCS
grant execute on function public.open_session(uuid, uuid, int, int) to authenticated;
grant execute on function public.mark_my_attendance(uuid) to authenticated;
grant execute on function public.close_session(uuid) to authenticated;
grant execute on function public.cancel_session(uuid) to authenticated;
grant execute on function public.set_attendance(uuid, uuid, public.attendance_status) to authenticated;
grant execute on function public.clear_must_change_password() to authenticated;
grant execute on function public.server_now() to authenticated;

-- Do not grant _finalize_session or close_expired_sessions to public / authenticated
revoke execute on function public._finalize_session(uuid, uuid) from public, anon, authenticated;
revoke execute on function public.close_expired_sessions() from public, anon, authenticated;
