// supabase/functions/reset-student-password/index.ts
// Deno TypeScript Edge Function for resetting a student's password by their teacher

import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.8";
import { z } from "https://esm.sh/zod@3.22.4";

const payloadSchema = z.object({
  student_id: z.string().uuid(),
});

function generateSecurePassword(length = 18): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=";
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => chars[byte % chars.length]).join("");
}

serve(async (req: Request) => {
  const allowedOrigin = Deno.env.get("ALLOWED_ORIGIN") || "*";

  const corsHeaders = {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

    const callerClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false },
    });

    const { data: { user }, error: userError } = await callerClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: profile, error: profileError } = await callerClient
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    if (profileError || !profile || profile.role !== "teacher") {
      return new Response(JSON.stringify({ error: "Forbidden: Teacher role required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const rawBody = await req.json();
    const parseResult = payloadSchema.safeParse(rawBody);
    if (!parseResult.success) {
      return new Response(JSON.stringify({ error: "Invalid request payload" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { student_id } = parseResult.data;

    // Verify student belongs to a class owned by this teacher
    const { data: studentRecord, error: studentError } = await callerClient
      .from("students")
      .select("id, profile_id, full_name, roll_number, email, class_id")
      .eq("id", student_id)
      .single();

    if (studentError || !studentRecord) {
      return new Response(JSON.stringify({ error: "Student not found or access denied" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify teacher owns this class
    const { data: classRecord, error: classError } = await callerClient
      .from("classes")
      .select("id")
      .eq("id", studentRecord.class_id)
      .eq("teacher_id", user.id)
      .single();

    if (classError || !classRecord) {
      return new Response(JSON.stringify({ error: "Forbidden: You do not own this student's class" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { persistSession: false },
    });

    const newTempPassword = generateSecurePassword(18);

    // Update user password in auth.users
    const { error: updateAuthError } = await adminClient.auth.admin.updateUserById(
      studentRecord.profile_id,
      { password: newTempPassword }
    );

    if (updateAuthError) {
      return new Response(JSON.stringify({ error: "Failed to update authentication credentials" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Set must_change_password = true in profiles
    const { error: profileUpdateError } = await adminClient
      .from("profiles")
      .update({ must_change_password: true })
      .eq("id", studentRecord.profile_id);

    if (profileUpdateError) {
      return new Response(JSON.stringify({ error: "Failed to update student profile security state" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Audit log (no passwords recorded)
    await adminClient.from("audit_logs").insert({
      actor_id: user.id,
      action: "student_password_reset",
      entity_type: "students",
      entity_id: student_id,
      metadata: {
        student_id,
        roll_number: studentRecord.roll_number,
        email: studentRecord.email,
      },
    });

    return new Response(
      JSON.stringify({
        success: true,
        student_id,
        full_name: studentRecord.full_name,
        roll_number: studentRecord.roll_number,
        temp_password: newTempPassword,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (_err) {
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
