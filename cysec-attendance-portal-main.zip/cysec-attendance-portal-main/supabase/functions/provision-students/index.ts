// supabase/functions/provision-students/index.ts
// Deno TypeScript Edge Function for batch provisioning student accounts

import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.8";
import { z } from "https://esm.sh/zod@3.22.4";

const studentRowSchema = z.object({
  full_name: z.string().min(1).max(100).trim(),
  roll_number: z.string().regex(/^[A-Za-z0-9-]{1,20}$/, "Invalid roll number format"),
  email: z.string().email().transform((v) => v.toLowerCase().trim()),
});

const payloadSchema = z.object({
  class_id: z.string().uuid(),
  students: z.array(studentRowSchema).min(1).max(100),
});

function generateSecurePassword(length = 18): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=";
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, (byte) => chars[byte % chars.length]).join("");
}

serve(async (req: Request) => {
  const allowedOrigin = Deno.env.get("ALLOWED_ORIGIN") || "*";

  const corsHeaders = {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Check request body size limit: 1 MB
    const contentLength = req.headers.get("content-length");
    if (contentLength && parseInt(contentLength, 10) > 1024 * 1024) {
      return new Response(JSON.stringify({ error: "Payload exceeds 1MB limit" }), {
        status: 413,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

    // Client with caller's JWT to verify caller's identity
    const callerClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
      auth: { persistSession: false },
    });

    const { data: { user }, error: userError } = await callerClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify caller is teacher
    const { data: profile, error: profileError } = await callerClient
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    if (profileError || !profile || profile.role !== "teacher") {
      return new Response(JSON.stringify({ error: "Forbidden: Teacher role required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const rawBody = await req.json();
    const parseResult = payloadSchema.safeParse(rawBody);
    if (!parseResult.success) {
      return new Response(JSON.stringify({ error: "Invalid request payload", details: parseResult.error.flatten() }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { class_id, students } = parseResult.data;

    // Verify teacher owns the class
    const { data: classData, error: classError } = await callerClient
      .from("classes")
      .select("id")
      .eq("id", class_id)
      .eq("teacher_id", user.id)
      .single();

    if (classError || !classData) {
      return new Response(JSON.stringify({ error: "Forbidden: You do not own this class" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check for intra-batch duplicate roll_number or email
    const seenRolls = new Set<string>();
    const seenEmails = new Set<string>();
    for (const s of students) {
      if (seenRolls.has(s.roll_number)) {
        return new Response(JSON.stringify({ error: `Duplicate roll number '${s.roll_number}' in batch` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (seenEmails.has(s.email)) {
        return new Response(JSON.stringify({ error: `Duplicate email '${s.email}' in batch` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      seenRolls.add(s.roll_number);
      seenEmails.add(s.email);
    }

    // Admin client with service_role key to create Auth users & bypass insertion restrictions
    const adminClient = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { persistSession: false },
    });

    const results: Array<{
      roll_number: string;
      email: string;
      full_name: string;
      status: "created" | "failed";
      error?: string;
      temp_password?: string;
    }> = [];

    for (const student of students) {
      let createdAuthUserId: string | null = null;
      try {
        const tempPassword = generateSecurePassword(18);

        // 1. Create auth user with email_confirm: true
        const { data: authUser, error: createAuthError } = await adminClient.auth.admin.createUser({
          email: student.email,
          password: tempPassword,
          email_confirm: true,
          user_metadata: { full_name: student.full_name },
        });

        if (createAuthError || !authUser.user) {
          throw new Error(createAuthError?.message || "Failed to create authentication user");
        }

        createdAuthUserId = authUser.user.id;

        // 2. Insert profile row
        const { error: profileInsertError } = await adminClient
          .from("profiles")
          .insert({
            id: createdAuthUserId,
            role: "student",
            full_name: student.full_name,
            must_change_password: true,
          });

        if (profileInsertError) {
          throw new Error(profileInsertError.message);
        }

        // 3. Insert student row
        const { data: studentRecord, error: studentInsertError } = await adminClient
          .from("students")
          .insert({
            profile_id: createdAuthUserId,
            class_id: class_id,
            roll_number: student.roll_number,
            full_name: student.full_name,
            email: student.email,
            is_active: true,
          })
          .select("id")
          .single();

        if (studentInsertError || !studentRecord) {
          throw new Error(studentInsertError?.message || "Failed to insert student record");
        }

        // 4. Audit log entry without passwords
        await adminClient.from("audit_logs").insert({
          actor_id: user.id,
          action: "student_created",
          entity_type: "students",
          entity_id: studentRecord.id,
          metadata: {
            class_id,
            roll_number: student.roll_number,
            email: student.email,
            full_name: student.full_name,
          },
        });

        results.push({
          roll_number: student.roll_number,
          email: student.email,
          full_name: student.full_name,
          status: "created",
          temp_password: tempPassword,
        });
      } catch (err: any) {
        // Rollback created auth user if anything failed
        if (createdAuthUserId) {
          try {
            await adminClient.auth.admin.deleteUser(createdAuthUserId);
          } catch (_) {
            // Ignore rollback cleanup errors
          }
        }

        results.push({
          roll_number: student.roll_number,
          email: student.email,
          full_name: student.full_name,
          status: "failed",
          error: err?.message || "Failed to provision student",
        });
      }
    }

    return new Response(JSON.stringify({ results }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (_err) {
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
